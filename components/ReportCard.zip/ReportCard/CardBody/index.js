import React, { Component } from 'react'
import { View } from 'react-native'
import PropTypes from 'prop-types'
import TalkAbout from './TalkAbout'
import Info from './Info'
import styles from './styles'

export default class ReportCard extends Component {
  render () {
    const { word, wordStyle, textStyle, info } = this.props
    const reports = info.map(({text, value}, index) => {
      const divider = info.length - 1 > index ? styles.dividerStyle : {}
      return <Info
        key={text}
        value={value}
        text={text}
        dividerStyle={divider} />
    })
    return (
      <View style={styles.container}>
        <View style={styles.infoStyle}>
          {reports}
        </View>
        <TalkAbout word={word} wordStyle={wordStyle} textStyle={textStyle} />
      </View>
    )
  }
}
ReportCard.defaultProps = {}

ReportCard.propTypes = {
  word: PropTypes.string.isRequired,
  wordStyle: PropTypes.object,
  textStyle: PropTypes.object,
  info: PropTypes.array
}
