import React, { Component } from 'react'
import { View, Text } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'

export default class ReportCard extends Component {
  render () {
    const { wordStyle, word, textStyle } = this.props
    return (
      <View>
        <View style={[ styles.triangleIcon, { backgroundColor: wordStyle.backgroundColor || 'transparent' } ]} />
        <View style={[styles.talkAboutContainer, wordStyle]}>
          <Text style={[styles.wordStyle, textStyle]}>
            {word}
          </Text>
        </View>
      </View>
    )
  }
}
ReportCard.defaultProps = {
  wordStyle: {
    backgroundColor: '#e6e6e6'
  },
  textStyle: {
    backgroundColor: '#e6e6e6'
  }
}

ReportCard.propTypes = {
  word: PropTypes.string.isRequired,
  wordStyle: PropTypes.object,
  textStyle: PropTypes.object
}
