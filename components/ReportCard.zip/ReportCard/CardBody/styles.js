import { StyleSheet, Dimensions, Platform } from 'react-native'

const { width } = Dimensions.get('window')
const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
    justifyContent: 'center'
  },
  talkAboutContainer: {
    borderRadius: 8,
    paddingRight: 15,
    paddingLeft: 15,
    paddingBottom: 15,
    marginLeft: 15,
    marginRight: 15,
    paddingTop: Platform.OS === 'android' ? 10 : 15
  },
  valueContainer: {
    flex: 1,
    alignItems: 'center'
  },
  valueStyle: {
    color: '#333',
    fontSize: width === 320 ? 28 : 30,
    lineHeight: 40
  },
  textStyle: {
    fontSize: 12,
    color: '#999'
  },
  wordStyle: {
    lineHeight: Platform.OS === 'android' ? 24 : 20
  },
  triangleIcon: {
    width: 12,
    height: 12,
    borderRadius: 2,
    alignSelf: 'center',
    position: 'absolute',
    backgroundColor: '#333',
    transform: [{ rotate: '45deg' }, { translateY: -3 }, { translateX: -4 }]
  },
  dividerStyle: {borderRightWidth: 1, borderRightColor: '#E8E8E8'},
  infoStyle: { marginBottom: 20, flexDirection: 'row', justifyContent: 'space-around' }
})

export default styles
