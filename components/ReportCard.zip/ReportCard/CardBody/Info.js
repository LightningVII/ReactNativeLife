import React, { Component } from 'react'
import { View, Text } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'

export default class Info extends Component {
  render () {
    const { text, value, dividerStyle } = this.props
    return (
      <View style={[styles.valueContainer, dividerStyle]}>
        <Text style={styles.valueStyle}>
          {value}
        </Text>
        <Text style={styles.textStyle}>
          {text}
        </Text>
      </View>
    )
  }
}
Info.defaultProps = {
  dividerStyle: {}
}

Info.propTypes = {
  text: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  dividerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.number]).isRequired
}
