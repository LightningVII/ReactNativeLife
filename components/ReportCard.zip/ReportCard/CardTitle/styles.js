import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  container: {
    height: 50,
    paddingLeft: 15,
    paddingRight: 15,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  logo: {
    width: 24,
    height: 24,
    resizeMode: 'contain'
  },
  label: { flexDirection: 'row', alignItems: 'center' },
  title: { fontSize: 16, color: '#333' },
  unit: { color: '#999' }
})

export default styles
