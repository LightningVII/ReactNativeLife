import React, { Component } from 'react'
import { View, Image, Text, TouchableOpacity } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'

export default class ReportCard extends Component {
  render () {
    const { title, logo, average, unit } = this.props
    return (
      <TouchableOpacity style={styles.container} onPress={() => console.log('123123')}>
        <View style={styles.label}>
          <Image style={styles.logo} source={logo} />
          <Text style={styles.title}>
            {' '}{title}
          </Text>
        </View>
        <View>
          <Text>
            平均{' '}
            {average}
            <Text style={styles.unit}>
              {unit}
            </Text>
          </Text>
        </View>
      </TouchableOpacity>
    )
  }
}
ReportCard.defaultProps = {}

ReportCard.propTypes = {
  title: PropTypes.string.isRequired,
  logo: PropTypes.number.isRequired,
  average: PropTypes.number.isRequired,
  unit: PropTypes.string.isRequired
}
