import React, { Component } from 'react'
import { View } from 'react-native'
import PropTypes from 'prop-types'
import CardTitle from './CardTitle'
import CardBody from './CardBody'

import styles from './styles'

export default class ReportCard extends Component {
  render () {
    const { reports } = this.props
    const reportsInfo = reports.map(
      ({ key, zhName, logo, report, style }, index) => (
        <View key={key} style={[styles.container, { marginBottom: 10 }]}>
          <CardTitle
            title={zhName}
            logo={logo}
            average={report.average}
            unit={report.unit}
          />
          <CardBody
            info={report.info}
            word={report.word}
            wordStyle={style.wordContainerStyle}
            textStyle={style.wordTextStyle}
          />
        </View>
      )
    )
    return <View>{reportsInfo}</View>
  }
}
ReportCard.defaultProps = {
  reports: []
}

ReportCard.propTypes = {
  reports: PropTypes.array
}
