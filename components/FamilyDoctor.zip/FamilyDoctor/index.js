import React, { Component } from 'react'
import { View, Image, Text, Dimensions } from 'react-native'
import PropTypes from 'prop-types'
import { PaButton } from '../chameleon/native'
import styles from './styles'
const {width} = Dimensions.get('window')
export default class FamilyDoctor extends Component {
  render () {
    const { jobTitle, name, talk, avatar, consult, handleConsultPress } = this.props
    return (
      <View style={styles.container}>
        <View style={styles.doctor}>
          <View style={styles.avatarContainer}>
            <Image style={styles.avatar} source={avatar} />
          </View>
          <View style={styles.info}>
            <View style={styles.title}>
              <Text style={styles.name}>
                {name}
              </Text>
              <Text style={styles.jobTitle}>
                {jobTitle}
              </Text>
            </View>
            <View style={styles.description}>
              <Text style={styles.talk}>
                {talk}
              </Text>
            </View>
          </View>
        </View>
        <PaButton
          width={width - 32}
          bgColor={{ colorStops: {'0': '#0DDDCF', '1': '#22CDD4'}, from: [0, 25], to: [325, 25] }}
          shadowOffset={{width: 0, height: 5}}
          shadowOpacity={0.5}
          shadowRadius={5}
          shadowColor='#1BD2D2'
          elevation={4}
          handleBtnClick={handleConsultPress}
          button={{dom: <Text style={styles.btnText}>{consult}</Text>}}
          otherStyles={{marginTop: 15, marginBottom: 15}} />
      </View>
    )
  }
}
FamilyDoctor.defaultProps = {}

FamilyDoctor.propTypes = {
  jobTitle: PropTypes.string,
  name: PropTypes.string.isRequired,
  talk: PropTypes.string.isRequired,
  consult: PropTypes.string.isRequired,
  avatar: PropTypes.number.isRequired,
  handleConsultPress: PropTypes.func.isRequired
}
