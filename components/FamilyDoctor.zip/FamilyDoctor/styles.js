import { StyleSheet, Dimensions, Platform } from 'react-native'

const {width} = Dimensions.get('window')
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFF',
    marginBottom: 10,
    paddingTop: 25,
    paddingBottom: 25,
    paddingLeft: 16,
    paddingRight: 16
  },
  doctor: {
    justifyContent: 'space-between',
    flexDirection: 'row'
  },
  avatarContainer: { alignSelf: 'flex-start', borderWidth: 0, borderRadius: 30 },
  avatar: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
    borderRadius: 30
  },
  info: {
    alignSelf: 'center',
    width: width - 102
  },
  name: {color: '#333', fontSize: 16},
  title: {
    alignItems: 'flex-end',
    flexDirection: 'row',
    marginBottom: Platform.OS === 'android' ? 2 : 8
  },
  jobTitle: {
    color: '#999',
    fontSize: 12,
    left: 6,
    bottom: 1
  },
  talk: {
    fontSize: 14,
    color: '#999',
    lineHeight: Platform.OS === 'android' ? 22 : 20
  },
  btnText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: '500'
  }
})

export default styles
