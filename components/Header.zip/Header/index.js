import React, { Component } from 'react'
import { Text, View, ImageBackground } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'

export default class Header extends Component {
  constructor (props) {
    super(props)
    this.setDay = this.setDay.bind(this)
  }
  setDay (date, day) {
    date.setDate(date.getDate() - date.getDay() + day)
    return this.formatDate(date)
  }

  formatDate (date) {
    const day = date.getDate()
    const month = date.getMonth() + 1
    const patch = num => (num > 9 ? '' : '0') + num
    return patch(month) + '月' + patch(day) + '日'
  }

  render () {
    const {tag, curDate, bgImage} = this.props
    const week = this.setDay(curDate, 1) + '-' + this.setDay(curDate, 7)
    return (
      <ImageBackground source={bgImage} style={styles.container}>
        <View style={styles.dateBtnContainer} >
          <Text style={styles.dateBtnText}>{week}</Text>
        </View>
        <Text style={styles.tagText}>
          {tag}
        </Text>
      </ImageBackground>
    )
  }
}
Header.defaultProps = {}

Header.propTypes = {
  tag: PropTypes.string.isRequired,
  curDate: PropTypes.object.isRequired
}
