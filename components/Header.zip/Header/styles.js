import { StyleSheet, Dimensions, Platform } from 'react-native'

const { width } = Dimensions.get('window')
const styles = StyleSheet.create({
  container: {
    width: width,
    height: 200,
    justifyContent: 'center',
    flex: 1
  },
  tagText: {
    backgroundColor: 'transparent',
    alignSelf: 'center',
    fontSize: 32,
    color: '#FFF',
    textShadowColor: '#999',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: Platform.OS === 'android' ? 10 : 1
  },
  dateBtnContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    height: 26,
    borderRadius: 13,
    marginBottom: Platform.OS === 'android' ? 10 : 20,
    paddingLeft: 15,
    paddingRight: 15,
    alignSelf: 'center',
    justifyContent: 'center',
    overflow: 'hidden'
  },
  dateBtnText: {
    fontSize: 12,
    color: '#FFF'
  }
})

export default styles
