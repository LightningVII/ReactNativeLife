import { StyleSheet, Platform, Dimensions } from 'react-native'
const {width, height} = Dimensions.get('window')
const isIphoneX = () => {
  return (
    Platform.OS === 'ios' &&
    !Platform.isPad &&
    !Platform.isTVOS &&
    (height === 812 || width === 812)
  )
}

const topBarHeight = Platform.OS === 'ios' ? (isIphoneX() ? 88 : 64) : 44

const styles = StyleSheet.create({
  topBarBg: {
    top: 0,
    position: 'absolute',
    height: topBarHeight,
    width: width,
    zIndex: 100,
    opacity: 0
  }
})

export default styles
