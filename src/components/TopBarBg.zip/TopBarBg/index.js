import React, { Component } from 'react'
import { View } from 'react-native'

import styles from './styles'

export default class TopBarBg extends Component {
  render () {
    const {bgColor, getTopBarBg} = this.props
    return <View ref={getTopBarBg} style={[styles.topBarBg, {backgroundColor: bgColor}]} />
  }
}

TopBarBg.defaultProps = {
  bgColor: '#00a6b0',
  getTopBarBg: ref => {}
}
