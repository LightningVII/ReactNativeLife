import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFF',
    paddingTop: 35,
    paddingBottom: 25,
    paddingLeft: 16,
    paddingRight: 16,
    borderRadius: 10
  },
  avatarContainer: {
    position: 'absolute',
    top: -30,
    alignSelf: 'center',
    borderWidth: 0,
    borderRadius: 30
  },
  avatar: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
    borderRadius: 30
  },
  info: {
    alignSelf: 'center'
  },
  name: {
    color: '#333',
    fontSize: 16
  },
  title: {
    alignItems: 'flex-end',
    alignSelf: 'center',
    flexDirection: 'row',
    marginBottom: 12
  },
  jobTitle: {
    color: '#999',
    fontSize: 12,
    left: 6,
    bottom: 1
  },
  talk: {
    fontSize: 14,
    color: '#333',
    lineHeight: 22
  },
  btnContainer: {
    width: 173,
    backgroundColor: '#459DFC',
    alignSelf: 'center',
    marginTop: 20,
    height: 40,
    borderRadius: 25,
    justifyContent: 'center',
    overflow: 'hidden'
  },
  btn: {
    borderRadius: 25,
    textAlign: 'center',
    color: '#FFF'
  }
})

export default styles
