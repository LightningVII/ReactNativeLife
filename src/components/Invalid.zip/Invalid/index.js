import React, { Component } from 'react'
import { View, Image, Text, TouchableOpacity } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'

export default class Invalid extends Component {
  render () {
    const { jobTitle, name, talk, avatar, consult, handleConsultPress, containerStyle } = this.props
    return (
      <View style={containerStyle}>
        <View style={styles.container}>
          <View style={styles.info}>
            <View style={styles.title}>
              <Text style={styles.name}>
                {name}
              </Text>
              <Text style={styles.jobTitle}>
                {jobTitle}
              </Text>
            </View>
            <View style={styles.description}>
              <Text style={styles.talk}>
                {talk}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            activeOpacity={0.6}
            onPress={handleConsultPress}
            style={styles.btnContainer}
            accessibilityTraits='button'
            accessibilityComponentType='button'>
            <Text style={styles.btn} allowFontScaling={this.props.allowFontScaling}>
              {consult}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.avatarContainer}>
          <Image style={styles.avatar} source={avatar} />
        </View>
      </View>
    )
  }
}
Invalid.defaultProps = {
  containerStyle: {
    marginTop: 120,
    marginLeft: 20,
    marginRight: 20
  }
}

Invalid.propTypes = {
  jobTitle: PropTypes.string,
  name: PropTypes.string.isRequired,
  talk: PropTypes.string.isRequired,
  consult: PropTypes.string.isRequired,
  avatar: PropTypes.number.isRequired,
  handleConsultPress: PropTypes.func.isRequired
}
