import React, { Component } from 'react'
import { Animated, Easing, View, Text, Image } from 'react-native'
import PropTypes from 'prop-types'
import styles from './styles'
import icon from './icon.png'

export default class AnimateCoin extends Component {
  constructor (props) {
    super()
    this.state = {
      opacityAnmValue: new Animated.Value(0),
      animateHeight: new Animated.Value(0)
    }
    this.initAnimation = this.initAnimation.bind(this)
  }
  componentWillReceiveProps (nextProps) {
    nextProps.showAnimate && this.initAnimation()
  }

  initAnimation () {
    Animated.sequence([
      Animated.parallel(
        [Animated.timing(new Animated.Value(0), {
          toValue: 1, // 目标值
          duration: 700, // 动画时间
          easing: Easing.bezier(.25, .1, .25, 1) // 缓动函数
        }),
          Animated.timing(this.state.animateHeight, {
            toValue: 0.8, // 目标值
            duration: 700, // 动画时间
            easing: Easing.bezier(.25, .1, .25, 1) // 缓动函数
          })]
      ), Animated.parallel(
        [Animated.timing(this.state.opacityAnmValue, {
          toValue: 0, // 目标值
          duration: 200, // 动画时间
          easing: Easing.bezier(.25, .1, .25, 1) // 缓动函数
        }),
          Animated.timing(this.state.animateHeight, {
            toValue: 1, // 目标值
            duration: 200, // 动画时间
            easing: Easing.bezier(.25, .1, .25, 1) // 缓动函数
          })]
      )]).start(finish => {
      finish && this.props.endEvent && this.props.endEvent()
    })
  }

  render () {
    console.log(this.state.opacityAnmValue)
    return (
      <Animated.View style={[styles.container, {opacity: this.state.opacityAnmValue, top: this.state.animateHeight.interpolate({ inputRange: [0, 1], outputRange: [0, -200] })}]}>
        <Image source={icon} resizeMode='cover' style={styles.iconImg} />
        <Text style={[styles.iconText]}>
          +
          {this.props.iconNum}
        </Text>
      </Animated.View>
    )
  }
}

AnimateCoin.propTypes = {

}
