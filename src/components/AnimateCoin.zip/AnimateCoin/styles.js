import { Dimensions, StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        height: 50,
        paddingTop: 400,
        position: 'absolute',
        alignSelf: 'center',
        alignItems: 'center',
        justifyContent: 'center',  
        flexDirection: 'row',
    },
    iconImg: {
        width: 50,
        height: 50,
        marginRight: 8,
    },
    iconText: {
        fontSize: 30,
        fontWeight: '600',
        color: '#FFCB00',
        backgroundColor: 'rgba(255,255,255,0)'
    }
  
});

export default styles;