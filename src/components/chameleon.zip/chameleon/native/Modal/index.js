import { Modal } from 'react-native';

export default Modal;