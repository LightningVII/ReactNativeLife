import {
  NativeModules,
} from 'react-native';

import clickLog from './beacon';

const { RNEvent } = NativeModules;

const logHandler = () => {
  let userId = '';
  let project = '';

  function init(userId, project, PEACON_URL){
    this.userId = userId;
    this.project = project;
    this.PEACON_URL = PEACON_URL;
  }
  // 进入页面，离开页面打点方法弃用，统一用事件打点方法
  // function setPageEnterLog(pageName){
  //   RNEvent.onResume(pageName);
  // }
  //
  // function setPageLeaveLog(pageName){
  //   RNEvent.onPause(pageName);
  // }

  function setEventLog(event, options = {}){
    if(Object.keys(options).length === 0){
      RNEvent.onEvent(event);
    }else{
      RNEvent.onEvent(event, '', options);
    }
  }

  // 日志
  function setLog(params) {
    RNEvent.log(params);
  }

  function setClickLog(params) {
    if (this.PEACON_URL) {
      clickLog(this.PEACON_URL, params);
    }
  }

  // 实时打点，50402开始支持
  function setRealTimeLog(event, options) {
    if(RNEvent.onRealtimeEvent) {
      RNEvent.onRealtimeEvent(event,options);
    } else {
      setEventLog(event, options);
    }
  }

  return {
      init,
      // setPageEnterLog,
      // setPageLeaveLog,
      setEventLog,
      setLog,
      setClickLog,
      setRealTimeLog
  };
}

export default logHandler();
