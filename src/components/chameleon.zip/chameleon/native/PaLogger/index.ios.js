import {
  NativeModules,
} from 'react-native';

import clickLog from './beacon';

const { RNViewControllerManager } = NativeModules;

const logHandler = () => {
    let userId = '';
    let project = '';

    function init(userId, project, PEACON_URL){
        this.userId = userId;
        this.project = project;
        this.PEACON_URL = PEACON_URL;
    }

    // 进入页面，离开页面打点方法弃用，统一用事件打点方法
    // function setPageEnterLog(pageName){
    //     RNViewControllerManager.trackPageBegin(pageName);
    // }
    //
    // function setPageLeaveLog(pageName){
    //     RNViewControllerManager.trackPageEnd(pageName);
    // }

    function setEventLog(event, options = {}){
        if(Object.keys(options).length === 0){
            RNViewControllerManager.trackEvent(event);
        }else{
            RNViewControllerManager.trackEventWithLabelAndParameters(event, '', options);
        }
    }

    function setLog(params) {
      // RNViewControllerManager.log(params);
    }

    function setClickLog(params) {
        if (this.PEACON_URL) {
            clickLog(this.PEACON_URL, params);
        }
    }

    // 实时打点，50402开始支持
    function setRealTimeLog(event, options) {
        if(RNViewControllerManager.trackRealtimeEventWithParameters) {
            RNViewControllerManager.trackRealtimeEventWithParameters(event,options);
        } else {
            setEventLog(event, options);
        }
    }

    return {
        init,
        // setPageEnterLog,
        // setPageLeaveLog,
        setEventLog,
        setLog,
        setClickLog,
        setRealTimeLog
    };
}

export default logHandler();
