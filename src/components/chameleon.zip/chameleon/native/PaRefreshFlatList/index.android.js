import React, { Component } from 'react';
import {
  Text,
  View,
  FlatList,
  Dimensions,
  Animated,
  PanResponder,
  Image,
  Easing,
} from 'react-native';
import styles from '../../common/PaRefreshFlatList/styles';
import PropTypes from 'prop-types';
import Item from '../../common/PaRefreshFlatList/item';
import ImagesPath from '../../common/PaRefreshFlatList/images';
import AndroidSwipeRefreshLayout from './AndroidSwipeRefreshLayout';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const { height, width } = Dimensions.get('window');

// 0: 未刷新; 1: 到达刷新点; 2: 刷新中; 3: 刷新完成
export const RefreshState = {
  pullToRefresh: 0,
  releaseToRefresh: 1,
  refreshing: 2,
  refreshdown: 3,
};

export const RefreshText = {
  pullToRefresh: 'pull to refresh',
  releaseToRefresh: 'release to refresh ',
  refreshing: 'refreshing...',
  refreshdown: 'refresh complete!'
};

export const FooterText = {
  pushToRefresh: 'pull to refresh',
  loading: 'refreshing...'
};

export default class PaRefreshFlatList extends Component {  
    static defaultProps = {
        initRefresh: false,
        data: [],
        hasNext: false,
        offset: 0,
        noRefreshControl: false
    };

    static propTypes = {
        initRefresh: PropTypes.bool,
        data: PropTypes.array,
        hasNext: PropTypes.bool,
        renderItem: PropTypes.func,
        renderHead: PropTypes.func,
        ItemSeparatorComponent: PropTypes.func,
        ListFooterComponent: PropTypes.func,
        onLoad: PropTypes.func,
        onRefreshed: PropTypes.func,
        offset: PropTypes.number,
        noRefreshControl: PropTypes.bool,
        forceUpdate: PropTypes.bool,
        extraData: PropTypes.any,
        style: PropTypes.any,
        onLockedTab: PropTypes.func
    };

    constructor() {
        super();
        this.state = {
            rotation: new Animated.Value(0),
            refreshState: RefreshState.pullToRefresh,
            refreshText: RefreshText.pullToRefresh,
            percent: 0,
            footerMsg: 'load more',
            toRenderItem: true
        };
        this._scrollEndY = 0;
        this.headerHeight = 150;
        this._marginTop = new Animated.Value();
        this.isAnimating = false; // Controls the same animation not many times during the sliding process
        this.beforeRefreshState = RefreshState.pullToRefresh;
        this.loadmore = true;
        this.refreshing = false;  // 刷新状态
    }

    componentWillMount() {
        const { noRefreshControl } = this.props;
        if (!noRefreshControl) {
            this._marginTop.setValue(-this.headerHeight);
            this._marginTop.addListener((v) => {
              const p = parseInt(( (this.headerHeight + v.value) / (this.headerHeight)) * 100);
              if (this.state.refreshState !== RefreshState.refreshdown)
                this.setState({ percent: `${p > 100 ? 100 : p}%` });
            });
        }
    }

    componentDidMount() {
        const { initRefresh, noRefreshControl, onLoad, onRefreshed, forceUpdate } = this.props;
        if ((!noRefreshControl && initRefresh) || forceUpdate) {
            // onLoad && onLoad('refresh').then(() => {
            //     onRefreshed && onRefreshed();
            //     this.isInit = false;
            // });
            this._onRefresh();
        }
    }

    _onRefresh() {
        try {
            this.refreshing = true;
            const { onLoad } = this.props;
            this.setRefreshState(true);
            // 滚动到顶部
            this._flatList && this._flatList._component && this._flatList._component.scrollToOffset({ animated: true, y: 0 });
            return onLoad && onLoad('refresh').then(() => {
                this.setRefreshState(false);
            }, () => {
                this.setRefreshState(false);
            }).catch(() => {
                this.setRefreshState(false);
            });
        } catch (e) {
            throw new Error('刷新函数不支持Promise');
        }
    }

    componentWillReceiveProps(nextProps, nextState) {
        // this.setRefreshState(nextProps.initRefresh);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUnmount() {
        this.t && clearTimeout(this.t);
    }

    setRefreshState(refreshing) {
        if (refreshing) {
            this.beforeRefreshState = RefreshState.refreshing;
            this.updateRefreshViewState(RefreshState.refreshing);
        } else {
            if (this.beforeRefreshState === RefreshState.refreshing) {
                this.beforeRefreshState = RefreshState.pullToRefresh;
                this.updateRefreshViewState(RefreshState.refreshdown);
            } else {
                // this.updateRefreshViewState(RefreshState.pullToRefresh)
            }
        }
    }

    updateRefreshViewState(refreshState = RefreshState.pullToRefresh) {
        switch (refreshState) {
            case RefreshState.pullToRefresh:
                this.setState({
                    refreshState: RefreshState.pullToRefresh, 
                    refreshText: RefreshText.pullToRefresh
                }, () => {
                    Animated.timing(
                        this._marginTop,
                        {
                            toValue: -this.headerHeight,
                            duration: 200,
                            easing: Easing.linear
                        }
                    ).start();
                });
                break;
            case RefreshState.releaseToRefresh:
                this.setState({
                    refreshState: RefreshState.releaseToRefresh, 
                    refreshText: RefreshText.releaseToRefresh });
                break;
            case RefreshState.refreshing: 
                this.setState({
                    refreshState: RefreshState.refreshing, 
                    refreshText: RefreshText.refreshing 
                }, () => {
                    Animated.timing(
                        this._marginTop,
                        {
                            toValue: -this.headerHeight * 0.5,
                            duration: 200,
                            easing: Easing.linear
                        }
                    ).start();
                });
                break;  
            case RefreshState.refreshdown:
                this.setState({
                    refreshState: RefreshState.refreshdown, 
                    refreshText: RefreshText.refreshdown 
                }, () => {
                    this.t = setTimeout(() => {
                        // 当刷新完成时，先回到初始状态保持100%, 然后在更新组件状态
                        Animated.timing(
                            this._marginTop,
                            {
                                toValue: -this.headerHeight,
                                duration: 200,
                                easing: Easing.linear
                        }).start(() => {
                            this.updateRefreshViewState(RefreshState.pullToRefresh);
                            const { onRefreshed } = this.props;
                            onRefreshed && onRefreshed();
                            this.refreshing = false;
                        });
                    }, 500);
                });
                break;
            default:
            
        }
    }

    _onEndReached = () => {
        const { onLoad, hasNext } = this.props;
        // this.loadmore: 控制请求次数
        // hasNext: 是否有下一页
        // this.refreshing: 是否处于正在刷新中
        if (this.loadmore && hasNext && !this.refreshing) {
            this.loadmore = false;
            onLoad && onLoad('more').then(() => {
                this.loadmore = true;
            });
        }
    }

    _onSwipe = (movement) => {
        if (this.state.refreshState >= RefreshState.refreshing) 
            return;
        this._scrollEndY = movement;
        this._marginTop.setValue(movement - this.headerHeight);
        if (movement >= this.headerHeight) {
            this.updateRefreshViewState(RefreshState.releaseToRefresh);
        } else if (movement < this.headerHeight) {
            if (this.state.refreshState === RefreshState.releaseToRefresh)
                this.updateRefreshViewState(RefreshState.pullToRefresh);
        }
        const { onLockedTab } = this.props;
        onLockedTab && onLockedTab(true);
        // console.log('调试中：_onSwipe', this._scrollEndY);
    }

    refreshLoadData = () => {
         // console.log('调试中：_onRefresh', this._scrollEndY);
        if (this.state.refreshState >= RefreshState.refreshing) 
            return;
        if (this._scrollEndY >= this.headerHeight * 0.5) {
            this._onRefresh();
        } else {
            // 下拉距离不够自动收回
            Animated.timing(
            this._marginTop,
            {
                toValue: -this.headerHeight,
                duration: 200,
                easing: Easing.linear
            }).start();
        }
        const { onLockedTab } = this.props;
        onLockedTab && onLockedTab(false);
    }

    _renderItem = (item) => {
        return <Item item={item} {...this.props} />;
    }

    _ListHeaderComponent = () => {
        // const { refreshState, refreshText, percent } = this.state;
        const { noRefreshControl, extraData, renderHead } = this.props;
        const head = renderHead ? <Item item={extraData} renderItem={renderHead} /> : null;
        if (noRefreshControl) {
            return head;
        }
        return (
            <View>
                <Animated.View style={styles.loadContainer}>
                    <Animated.Image 
                        source={ImagesPath.refreshbg} 
                        style={styles.loadBg} 
                        resizeMode="contain" />
                    <Animated.Image 
                        source={ImagesPath.refresh} 
                        style={styles.loading} 
                        resizeMode="contain" />
                </Animated.View>
                { head }
            </View>    
        );
    }

    _ListFooterComponent = () => {
        const { hasNext, data, ListFooterComponent } = this.props;
        if (data.length === 0) {
            return null;
        }
        if (hasNext) {
            return (
                <Animated.View style={styles.moreLoadContainer}>
                    <Animated.Image 
                        source={ImagesPath.loading} 
                        style={styles.moreloading} 
                        resizeMode="contain" />
                    <Text>正在加载中...</Text>  
                </Animated.View> 
            );
        } else {
            if (ListFooterComponent !== undefined ) {
                return ListFooterComponent;
            }
            return (
                <View style={styles.lastTipContainer}>
                    <Animated.Image 
                        source={ImagesPath.lastTip} 
                        style={styles.lastTipImg} 
                        resizeMode="contain" />
                    <Text style={styles.lastTipText}>已经到底啦</Text>
                </View>  
            );
        }
    }

    _ListEmptyComponent = () => {
        const offset = this.props.offset || 0;
        if (this.state.refreshState !== RefreshState.pullToRefresh && this.refreshing) {
            return <View style={[ styles.emptyContainer, { height: height - offset, width }]} />;
        }
        return (
            <View style={[ styles.emptyContainer, { height: height - offset, width }]}>
                <Image 
                    source={ImagesPath.kong} 
                    style={styles.emptyImg} 
                    resizeMode="contain" />
                <Text style={styles.emptyText}>这里空空如野，什么也没搜到~</Text>
            </View>
        );
    }

    _ItemSeparatorComponent = (data) => {
        const { ItemSeparatorComponent } = this.props;
        return ItemSeparatorComponent ? 
            <Item item={data.leadingItem} renderItem={ItemSeparatorComponent} /> : 
            null;
    }

    render() {
        const { data, extraData, noRefreshControl, style } = this.props;
        return (
            <AndroidSwipeRefreshLayout 
                ref={ component => this._swipeRefreshLayout = component }
                enabledPullUp={true}
                enabledPullDown={true}
                onSwipe={this._onSwipe}
                onRefresh={this.refreshLoadData}
                style={styles.container}>
                <AnimatedFlatList
                    ref={ flatlist => { this._flatList = flatlist; }}
                    {...this.props}
                    data={data || []}
                    extraData={extraData}
                    renderItem={this._renderItem}
                    keyExtractor={(v, i) => i }
                    windowSize={5}
                    onMoveShouldSetResponder={() => false}
                    ListHeaderComponent={this._ListHeaderComponent}
                    ListFooterComponent={this._ListFooterComponent}
                    ListEmptyComponent={this._ListEmptyComponent}
                    ItemSeparatorComponent={this._ItemSeparatorComponent}
                    onEndReached={this._onEndReached} 
                    onEndReachedThreshold={0.1}
                    initialNumToRender={6}
                    style={[ styles.container, 
                        { 
                            marginTop: !noRefreshControl ? this._marginTop.interpolate({
                                inputRange: [ -this.headerHeight, 0, 500 ],
                                outputRange: [ -this.headerHeight, 0, 150 ]
                            }) : 0 
                        }, style ]}
                />
            </AndroidSwipeRefreshLayout>    
        );
    }
}