import React, { Component } from 'react';
import {
  Text,
  View,
  FlatList,
  Dimensions,
  Animated,
  PanResponder,
  Image
} from 'react-native';
import styles from '../../common/PaRefreshFlatList/styles';
import PropTypes from 'prop-types';
import Item from '../../common/PaRefreshFlatList/item';
import ImagesPath from '../../common/PaRefreshFlatList/images';

const { height, width } = Dimensions.get('window');

// 0: 未刷新; 1: 到达刷新点; 2: 刷新中; 3: 刷新完成
export const RefreshState = {
  pullToRefresh: 0,
  releaseToRefresh: 1,
  refreshing: 2,
  refreshdown: 3,
};

export const RefreshText = {
  pullToRefresh: 'pull to refresh',
  releaseToRefresh: 'release to refresh ',
  refreshing: 'refreshing...',
  refreshdown: 'refresh complete!'
};

export const FooterText = {
  pushToRefresh: 'pull to refresh',
  loading: 'refreshing...'
};

export default class PaRefreshFlatList extends Component {  
    static defaultProps = {
        initRefresh: false,
        data: [],
        hasNext: false,
        offset: 0,
        noRefreshControl: false
    };

    static propTypes = {
        initRefresh: PropTypes.bool,
        data: PropTypes.array,
        hasNext: PropTypes.bool,
        renderItem: PropTypes.func,
        renderHead: PropTypes.func,
        ItemSeparatorComponent: PropTypes.func,
        ListFooterComponent: PropTypes.func,
        onLoad: PropTypes.func,
        onRefreshed: PropTypes.func,
        offset: PropTypes.number,
        noRefreshControl: PropTypes.bool,
        extraData: PropTypes.any,
        style: PropTypes.any,
        onScroll: PropTypes.func,
        forceUpdate: PropTypes.bool
    };

    constructor() {
        super();
        this.state = {
            rotation: new Animated.Value(0),
            refreshState: RefreshState.pullToRefresh,
            refreshText: RefreshText.pullToRefresh,
            percent: 0,
            footerMsg: 'load more',
            toRenderItem: true
        };
        this._scrollEndY = 0;
        this.headerHeight = 150;
        this.mTop = 0; // Record distance from top to top
        this.isOnMove = false; // Distinguish whether the finger is triggered Slip; Calculate the sliding percentage
        this.isAnimating = false; // Controls the same animation not many times during the sliding process
        this.beforeRefreshState = RefreshState.pullToRefresh;
        this.loadmore = true;
        this.refreshing = false;  // 刷新状态
    }

    componentWillMount() {
        const { noRefreshControl } = this.props;
        if (!noRefreshControl) {
            this._panResponder = PanResponder.create({
                onStartShouldSetPanResponder: (event, gestureState) => true,
                onStartShouldSetPanResponderCapture: (event, gestureState) => true,
                onMoveShouldSetPanResponder: (event, gestureState) => false,
                onMoveShouldSetPanResponderCapture: (event, gestureState) => false,
                onPanResponderTerminationRequest: (event, gestureState) => true,
                onPanResponderGrant: (event, gestureState) => {
                    this.onStart(event, gestureState);
                },
                onPanResponderMove: (event, gestureState) => {
                    this.onMove(event, gestureState);
                },
                onPanResponderRelease: (event, gestureState) => {
                    this.onEnd(event, gestureState);
                }
            });
        }
    }

    componentDidMount() {
        const { initRefresh, noRefreshControl, onLoad, onRefreshed, forceUpdate } = this.props;
        if ((!noRefreshControl && initRefresh) || forceUpdate) {
            // onLoad && onLoad('refresh').then(() => {
            //     onRefreshed && onRefreshed();
            //     this.isInit = false;
            // });
            this._onRefresh();
        }
    }

    _onRefresh() {
        try {
            this.refreshing = true;
            const { onLoad } = this.props;
            this.setRefreshState(true);
            this._flatList && this._flatList.scrollToOffset({ y: 0 });
            return onLoad && onLoad('refresh').then(() => {
                this.setRefreshState(false);
            }, () => {
                this.setRefreshState(false);
            }).catch(() => {
                this.setRefreshState(false);
            });
        } catch (e) {
            throw new Error('刷新函数不支持Promise');
        }
    }

    componentWillReceiveProps(nextProps, nextState) {
      // window.console.log(nextProps.data);
        // this.setRefreshState(nextProps.initRefresh);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUnmount() {
        this.t && clearTimeout(this.t);
        this.tt && clearTimeout(this.tt);
    }

    setRefreshState(refreshing) {
        if (refreshing) {
            this.beforeRefreshState = RefreshState.refreshing;
            this.updateRefreshViewState(RefreshState.refreshing);
        } else {
            if (this.beforeRefreshState === RefreshState.refreshing) {
                this.beforeRefreshState = RefreshState.pullToRefresh;
                this.updateRefreshViewState(RefreshState.refreshdown);
            } else {
                // this.updateRefreshViewState(RefreshState.pullToRefresh)
            }
        }
    }

    updateRefreshViewState(refreshState = RefreshState.pullToRefresh) {
        const { noRefreshControl } = this.props;
        switch (refreshState) {
            case RefreshState.pullToRefresh:
                this.setState({ 
                    refreshState: RefreshState.pullToRefresh, 
                    refreshText: RefreshText.pullToRefresh
                });
            break;
            case RefreshState.releaseToRefresh:
                this.setState({
                    refreshState: RefreshState.releaseToRefresh, 
                    refreshText: RefreshText.releaseToRefresh
                });
            break;
            case RefreshState.refreshing:
                this.setState({
                    refreshState: RefreshState.refreshing, 
                    refreshText: RefreshText.refreshing
                }, () => {
                    !noRefreshControl && this._flatList && this._flatList.scrollToOffset({ animated: true, offset: -this.headerHeight * 0.5 });
                });
            break;
            case RefreshState.refreshdown:
                this.setState({
                    refreshState: RefreshState.refreshdown, 
                    refreshText: RefreshText.refreshdown, percent: 100, toRenderItem: true }, () => {
                    // This delay is shown in order to show the refresh time to complete the refresh
                    this.t = setTimeout(() => {
                        !noRefreshControl && this._flatList && this._flatList.scrollToOffset({ animated: true, offset: 0 });
                        this.tt = setTimeout(() => {
                            this.updateRefreshViewState(RefreshState.pullToRefresh);
                        }, 500);
                        const { onRefreshed } = this.props;
                        onRefreshed && onRefreshed();
                        this.refreshing = false;
                    }, 500);
                });
                break;
            default:
                break;
        }
    }

    _onEndReached = () => {
        const { onLoad, hasNext } = this.props;
        // this.loadmore: 控制请求次数
        // hasNext: 是否有下一页
        // this.refreshing: 是否处于正在刷新中
        if (this.loadmore && hasNext && !this.refreshing) {
            this.loadmore = false;
            onLoad && onLoad('more').then(() => {
                this.loadmore = true;
            });
        }
    }

    _onScroll = (e) => {
        const { y } = e.nativeEvent.contentOffset;
        this._scrollEndY = y;
        if (this._scrollEndY === 0) this.setState({ toRenderItem: true });
        if (!this.isOnMove && -y >= 0) {
            // 刷新状态下，上推列表依percent然显示100%
            const p = parseInt(( -y / (this.headerHeight)) * 100);
            if (this.state.refreshState !== RefreshState.refreshdown)
                this.setState({ percent: (p > 100 ? 100 : p) });
        }
        const { onScroll } = this.props;
        onScroll && onScroll(e);
    }

    onStart(e, g) {
        this.isOnMove = true;
        this.loading = true;
        this.setState({ toRenderItem: false }); 
    }

    onMove(e, g) {
        this.mTop = g.dy;
        if (g.dy >= 0) {
            let p = parseInt(( g.dy / (2 * this.headerHeight)) * 100);
            p = p > 100 ? 100 : p;
            this.setState({ percent: p });
            if (p < 100) {
                this.updateRefreshViewState(RefreshState.pullToRefresh);
            } else {
                this.updateRefreshViewState(RefreshState.releaseToRefresh);
            }
        }
    }

    onEnd(e, g) {
        this.isOnMove = false;
        // if (this._scrollEndY < -this.headerHeight * 0.4) {
        //     this._onRefresh();
        // }
    }

    onTouchEnd = (e) => {
        // 避免多指触控导致重复请求
        if (e.nativeEvent.touches.length > 0) {
            return;
        }
        if (this._scrollEndY < -this.headerHeight * 0.4 && this.loading) {
            this._onRefresh();
            this.loading = false; 
            this.isOnMove = false;
        }
    }

    _renderItem = (item) => {
        return <Item item={item} {...this.props} />;
    }

    _ListHeaderComponent = () => {
        // const { refreshState, refreshText, percent } = this.state;
        const { noRefreshControl, extraData, renderHead } = this.props;
        const head = renderHead ? <Item item={extraData} renderItem={renderHead} /> : null;
        if (noRefreshControl) {
            return head;
        }
        return (
            <View>
                <Animated.View style={styles.loadContainer}>
                    <Animated.Image 
                        source={ImagesPath.refreshbg} 
                        style={styles.loadBg} 
                        resizeMode="contain" />
                    <Animated.Image 
                        source={ImagesPath.refresh} 
                        style={styles.loading} 
                        resizeMode="contain" />
                </Animated.View>
                { head }
            </View>    
        );
    }

    _ListFooterComponent = () => {
        const { hasNext, data, ListFooterComponent } = this.props;
        if (data.length === 0) {
            return null;
        }
        if (hasNext) {
            return (
                <Animated.View style={styles.moreLoadContainer}>
                    <Animated.Image 
                        source={ImagesPath.loading} 
                        style={styles.moreloading} 
                        resizeMode="contain" />
                    <Text>正在加载中...</Text>  
                </Animated.View> 
            );
        } else {
            if (ListFooterComponent !== undefined ) {
                return ListFooterComponent;
            }
            return (
                <View style={styles.lastTipContainer}>
                    <Animated.Image 
                        source={ImagesPath.lastTip} 
                        style={styles.lastTipImg} 
                        resizeMode="contain" />
                    <Text style={styles.lastTipText}>已经到底啦</Text>
                </View>  
            );
        }
    }

    _ListEmptyComponent = () => {
        const offset = this.props.offset || 0;
        if (this.state.refreshState !== RefreshState.pullToRefresh && this.refreshing) {
            return <View style={[ styles.emptyContainer, { height: height - offset, width }]} />;
        }
        return (
            <View style={[ styles.emptyContainer, { height: height - offset, width }]}>
                <Image 
                    source={ImagesPath.kong} 
                    style={styles.emptyImg} 
                    resizeMode="contain" />
                <Text style={styles.emptyText}>这里空空如野，什么也没搜到~</Text>
            </View>
        );
    }

    _ItemSeparatorComponent = (data) => {
        const { ItemSeparatorComponent } = this.props;
        return ItemSeparatorComponent ? 
            <Item item={data.leadingItem} renderItem={ItemSeparatorComponent} /> : 
            null;
    }

    render() {
        const { data, extraData, noRefreshControl, style } = this.props;
        const pan = !noRefreshControl ? this._panResponder.panHandlers : {};
        return (
            <FlatList
                ref={ flatlist => { this._flatList = flatlist; }}
                {...pan}
                {...this.props}
                onScroll={this._onScroll}
                data={data || []}
                onTouchEnd={this.onTouchEnd}
                windowSize={9}
                extraData={extraData}
                renderItem={this._renderItem}
                keyExtractor={(v, i) => i }
                ListHeaderComponent={this._ListHeaderComponent}
                ListFooterComponent={this._ListFooterComponent}
                ListEmptyComponent={this._ListEmptyComponent}
                ItemSeparatorComponent={this._ItemSeparatorComponent}
                onEndReached={this._onEndReached} 
                onEndReachedThreshold={0.1}
                style={[ styles.container, { marginTop: !noRefreshControl ? -this.headerHeight : 0 }, style ]}
            />
        );
    }
}