import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    ART
} from 'react-native';
import PropTypes from 'prop-types';

import styles from './styles';

const {Surface, Group, Shape, LinearGradient, Path} = ART;

class Button extends Component {
  constructor(props) {
    super(props);
    this.width = props.width || 325;
    this.height = props.height || 50;
    this.radius = props.radius || 25;
    this.activeOpacity = props.activeOpacity || 1;
    this.bgColor = this.handleColor(props.bgColor || 'transparent');
    this.shadowOffset = props.shadowOffset || {width: 0, height: 0};  
    this.shadowOpacity = props.shadowOpacity || 0;
    this.shadowRadius = props.shadowRadius || 0;
    this.shadowColor = props.shadowColor || 'transparent';
    this.elevation= props.elevation || 0;
    this.handleBtnClick = props.handleBtnClick; 
    this.button = props.button;
    this.content = props.button && props.button.content ? props.button.content : '';
    this.autoMakeLogName = props.autoMakeLogName || '';
    this.otherStyles = props.otherStyles || {};
  }

  componentWillReceiveProps(nextProps){
    this.bgColor = this.handleColor(nextProps.bgColor || 'transparent');
    this.shadowOffset = nextProps.shadowOffset || {width: 0, height: 0};  
    this.shadowOpacity = nextProps.shadowOpacity || 0;
    this.shadowRadius = nextProps.shadowRadius || 0;
    this.shadowColor = nextProps.shadowColor || 'transparent';
    this.button = nextProps.button;
    this.content = nextProps.button && nextProps.button.content ? nextProps.button.content : '';
    this.autoMakeLogName = nextProps.autoMakeLogName;
    this.otherStyles = nextProps.otherStyles || {};
  }

  handleColor(color) {
    if (typeof color === 'string') {
      return color;
    } else if (typeof color === 'object') {
      const { colorStops, from, to } = color;
      const pos = from.concat(to);
      return  new LinearGradient(colorStops, ...pos);
    }
  }

  getBgPath() {
    return new Path()
      .moveTo(0, 0)
      .lineTo(0, this.height)
      .lineTo(this.width, this.height)
      .lineTo(this.width, 0)
      .close();
  }

  render() {
      const btnDom = this.button && this.button.dom ?  this.button.dom 
                                    : 
                                    <Text style={styles.btnText}>{this.content}</Text>
      return (
        <TouchableOpacity activeOpacity={this.activeOpacity} style={[styles.btn, {width: this.width,height: this.height,borderRadius: this.radius,shadowOffset: this.shadowOffset, shadowOpacity: this.shadowOpacity,  shadowRadius: this.shadowRadius,  shadowColor: this.shadowColor,elevation: this.elevation, }, this.otherStyles]} onPress={this.handleBtnClick} testID={this.autoMakeLogName}>
          <View style={[styles.btnBackground, {borderRadius: this.radius,}]}>
            <Surface width={ this.width } height={ this.height }>
              <Group>
                    <Shape
                      d={ this.getBgPath() }
                      fill={this.bgColor}
                    />
              </Group>
            </Surface>
          </View>
          <View style={[styles.btnTextContainer, {width:this.width,height: this.height,borderRadius: this.radius,}]}>
            {btnDom}
          </View>
        </TouchableOpacity>
      )
  }
}

Button.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  radius: PropTypes.number,
  bgColor: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object
  ]),
  activeOpacity: PropTypes.number,
  handleBtnClick: PropTypes.func,
  shadowOffset: PropTypes.object,  
  shadowOpacity: PropTypes.number,  
  shadowRadius: PropTypes.number,  
  shadowColor: PropTypes.string,
  elevation: PropTypes.number, 
  button: PropTypes.object,  
  autoMakeLogName: PropTypes.string,
  otherStyles: PropTypes.object,  
};

export default Button;
