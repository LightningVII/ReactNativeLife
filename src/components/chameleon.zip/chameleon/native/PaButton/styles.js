import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  btn: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnBackground: {
    overflow: 'hidden'
  },
  btnTextContainer:{
    position: 'absolute',
    top: 0,
    left: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent'
  },
  btnText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '500'
  },
})

export default styles
