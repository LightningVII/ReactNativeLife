import PaTopBar from '../../common/PaTopBar'
export default PaTopBar