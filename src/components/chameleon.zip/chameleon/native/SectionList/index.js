import { SectionList } from 'react-native';

export default SectionList;