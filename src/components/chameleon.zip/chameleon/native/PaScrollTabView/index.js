import PaScrollTabView from '../../common/PaScrollTabView'
export default PaScrollTabView