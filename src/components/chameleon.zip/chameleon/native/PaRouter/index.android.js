import { NativeModules } from 'react-native';

const RNNavigator = NativeModules.RNNavigator;
const RNScheme = NativeModules.RNScheme;

// 跳转到项目内其他页面
const transitionTo = (options) => {
    const { appId, moduleId, container, pageTag, params, closeSelf=false } = options;
    RNNavigator.openNewRNView(appId, moduleId, container, pageTag, params, closeSelf);
}

// 关闭页面
const closeCurrentPage = (pageTag) => {
    RNNavigator.finishRNView(pageTag);
}

// 跳转到Native
const transitionToNative = (options) => {
    const { url, pageTag } = options;
    pageTag ? RNScheme.rnDispatchSchemeWithPageTag(url, pageTag) : RNScheme.rnDispatchScheme(url);
}

// 跳转到Webview
const transitionToWebview = (options) => {
    const { url, pageTag } = options;
    const openUrl = url.indexOf('pajk:') === -1 ? `pajk://global_h5_opennewpage?content={"url":"${encodeURIComponent(url)}"}` : url;
    return pageTag ? RNScheme.rnDispatchSchemeWithPageTag(openUrl, pageTag) : RNScheme.rnDispatchScheme(openUrl);

}

export default {
    transitionTo,
    transitionToNative,
    closeCurrentPage,
    transitionToWebview
}
