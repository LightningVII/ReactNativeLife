import { NativeModules } from 'react-native';
import { Promise } from 'es6-promise';
const { RNNavigator, RNScheme, RNDeviceInfoManager } = NativeModules;

// 设置标题
const setTitle = (title, pageTag) => {

}

const scheme = (scheme, pageTag = undefined) => pageTag ? RNScheme.rnDispatchSchemeWithPageTag(scheme, pageTag) : RNScheme.rnDispatchScheme(scheme);

const getAppVersion = () => {
	return new Promise((resolve, reject) => {
		const version = RNDeviceInfoManager.getAppVersionCode();
		resolve(version || 0);
  });
}

export default {
    setTitle,
    scheme,
    getAppVersion
}
