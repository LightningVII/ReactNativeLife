import { NativeModules } from 'react-native';
import { Promise } from 'es6-promise';
const { RNViewControllerManager: RNViewManager, RNScheme, RNDeviceInfoManager } = NativeModules;

// 设置标题
const setTitle = (title, pageTag) => {
    RNViewManager.title(title, pageTag);
}

const scheme = (scheme, pageTag = undefined) => pageTag ? RNScheme.rnDispatchSchemeWithPageTag(scheme, pageTag) : RNScheme.rnDispatchScheme(scheme);

const getAppVersion = () => {
	return new Promise((resolve, reject) => {
		const type = RNDeviceInfoManager.appVersion;
		const newType = type.split('.').join('0');
		resolve(newType ? Number(newType) : 0);
  });
}

export default {
    setTitle,
    scheme,
    getAppVersion
}
