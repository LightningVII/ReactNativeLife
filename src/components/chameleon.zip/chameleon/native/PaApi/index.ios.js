import { NativeModules } from 'react-native';

const RNAPIManager = NativeModules.RNAPIManager;

const securityMap = {
    'UserLogin': RNAPIManager.RNSecurityType_UserLogin,
    'None': RNAPIManager.RNSecurityType_None
}

function request(params) {
    const { _mt, _st, _api, ...others } = params;
    others[RNAPIManager.RNAPIMethodName] = _mt;
    others[RNAPIManager.RNAPISecurityType] = securityMap[_st];
    return RNAPIManager.request(others);
}

export default { request };