import {
  NativeModules,
} from 'react-native';

const { ApiDispatcher, ApiManager } = NativeModules;
const securityMap = {
  'UserLogin': ApiManager.RNSecurityType_UserLogin,
  'None': ApiManager.RNSecurityType_None
}
const request = (params) => {
  const { _mt, _st, _api, ...others } = params;
  return ApiDispatcher.sendRequest({
    [ApiManager.RNAPIMethodName]: _mt, [ApiManager.RNAPISecurityType] : securityMap[_st], _params: others
  }).then((data)=> {
    let result = data;
    try { 
      result = JSON.parse(data);
    } catch (error) {
 
    }
    return result;
  });
};

export default { request };