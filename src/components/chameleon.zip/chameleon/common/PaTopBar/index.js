import React, { Component } from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    StyleSheet,
    Dimensions
} from 'react-native';
import styles from './styles';
import { PaRouter } from 'chameleon/native';

export default class TopBar extends Component {
    static APPBAR_HEIGHT = styles.APPBAR_HEIGHT;

    constructor(props) {
        super(props)
        this.backgroundColor = this.props.style && this.props.style.backgroundColor || '#f8f8f8';
    }
    
    renderLeft = () => {
         const { style, forceShowBack, left, pageTag, backBtnColor } = this.props;
         let leftdom = <View/>;
         if(forceShowBack){
            leftdom = <View style={[ styles.backBtn, backBtnColor && { borderColor: backBtnColor } ]}/>;
         }else if(!left){
            leftdom = <View/>;
         }else if(left.icon){
            leftdom = <Image style={[styles.image,{paddingLeft: 15}]} source={left.icon}/>;
         }else{
            leftdom = left.view || <View/>; 
         }

         let event;
         if(forceShowBack && (!left || !left.notUseDefaultEvent)){
            event = () => PaRouter.closeCurrentPage(pageTag);
         }
        else if(left && left.onPress){
            event = left.onPress;
         }

         return (
            <TouchableOpacity style={[ styles.navLeft, left && left.style ]} onPress={event}>
                {leftdom}
            </TouchableOpacity>
        );
    }

    renderCenter = () => {
        const { style, title, center, numberOfLines } = this.props;
        let centerdom = <View/>;
        if(title){
            centerdom = <Text style={[styles.CenterText,style && {color:style.color}]} numberOfLines={ numberOfLines || 1 }>{title}</Text>;
        }else if(center){
            centerdom = center;
        }
        return (
            <View style={styles.navCenter}>
                {centerdom || <View/>}
            </View>
        )
    }

    renderRight = () => {
        const { right } = this.props;
        let rightdom = <View/>;
        if(right && right.buttons && right.buttons instanceof Array){
            rightdom = right.buttons.map((item,index)=>{
                return (
                    <TouchableOpacity key={index} style={styles.button} onPress={item && item.onPress} testID={item && item.testID}>
                        {item.icon && <Image style={[styles.image]} source={item.icon} />}
                        {item.text && <Text style={{fontSize:item.icon?10:15,color:item.color}}>{item.text}</Text>}
                    </TouchableOpacity>
                )
            });
        }else if(right && right.view){
            rightdom = right.view || <View/>; 
        }

        return (
            <View style={styles.navRight}>
                {rightdom}
            </View>
        )
    }

    render() {
        const { style, contentStyle = {}, forceShowBack, title, right, center, hideBar, hideLeft, hideRight } = this.props;
        let bodyStyle={};
        if(style && style.borderColor){
            bodyStyle["borderBottomWidth"] = StyleSheet.hairlineWidth;
            bodyStyle["borderBottomColor"] = style.borderColor;
            bodyStyle["paddingBottom"] = 1;
        }

        if(hideBar) return null;

        return (
            <View ref={this.props.kkk} style={[styles.nav, {width: Dimensions.get('window').width, backgroundColor:this.backgroundColor}, bodyStyle, {...contentStyle}]}>
                {!hideLeft && this.renderLeft()}
                {this.renderCenter()}
                {!hideRight && this.renderRight()}
            </View>
        )
    }
}
