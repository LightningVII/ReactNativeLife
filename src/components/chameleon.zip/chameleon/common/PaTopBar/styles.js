import React, {
    Platform,
    Dimensions,
    StyleSheet
} from 'react-native';

function isIphoneX() {
    const dimen = Dimensions.get('window');
    return (
        Platform.OS === 'ios' &&
        !Platform.isPad &&
        !Platform.isTVOS &&
        (dimen.height === 812 || dimen.width === 812)
    );
}

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? (isIphoneX() ? 44 : 20) : 0;
const TOP_HEIGHT = 44;
const APPBAR_HEIGHT = TOP_HEIGHT + STATUSBAR_HEIGHT;
const { width:SCREEN_WIDTH } = Dimensions.get('window');

var styles = StyleSheet.create({
    nav: {
        // width: SCREEN_WIDTH,
        paddingTop: STATUSBAR_HEIGHT,   
        height: APPBAR_HEIGHT,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        position:"relative"
    },
    backBtn:{
        width: 14,
        height: 14,
        borderBottomWidth: 1,
        borderLeftWidth: 1,
        transform: [{
            rotateZ: '45deg'
        }],
        borderColor: '#212121'
    },
    navLeft: {
        paddingLeft: 15,
        width: 70,
        height: TOP_HEIGHT,
        flexDirection: 'column',
        justifyContent: 'center'
    },
    navRight: {
        width: 70,
        height: TOP_HEIGHT,
        flexDirection:"row",
        justifyContent:"flex-end"
    },
    navCenter: {
        flex:1,
        height: TOP_HEIGHT,        
        flexDirection: 'row',
        alignItems:'center'
    },
    CenterText:{
        flex:1,
        flexDirection: 'row',
        textAlign: 'center',
        color: '#000000',
        fontSize:18
    },
    image:{
        width:22,
        height:22
    },
    button:{
        paddingRight: 15,
        flexDirection: 'column',
        justifyContent:"center",
        alignItems:"center"
    }
})

styles.APPBAR_HEIGHT = APPBAR_HEIGHT;

export default styles;
