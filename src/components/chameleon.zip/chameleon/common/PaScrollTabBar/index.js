import React, { Component } from 'react';
import {
  TouchableHighlight,
  Text,
  View,
  Animated,
  ViewPropTypes,
  Dimensions,
  I18nManager,
  Platform,
  ScrollView,
  Image,
  Modal
} from 'react-native';
import styles from './styles';
import PropTypes from 'prop-types';
import Tab from './tab';
import isEqual from 'lodash/isEqual';

const WINDOW_HEIGHT = Dimensions.get('window').height;
const shadow = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAmCAMAAAA/fHFyAAAAM1BMVEUAAAD7+/vz8/Pw8PDt7e39/f34+Pjg4ODn5+f19fXq6urk5OTi4uLU1NTb29vZ2dnW1ta2dqLxAAAAAXRSTlMAQObYZgAAAF5JREFUGNN10EkOwCAIBdAKFscO9z9tEz6/m1Y3LxFkcPs7e5gCg9YQNcG1aJgR1u62XF3pw9OlFldh0nHCebl53rAcS5nHd6zDuuzDvpyDc3FOqNyDe3FP7v3+w+c8aukCY/QFGYsAAAAASUVORK5CYII=';

const iPhone6Height = 667;
const getResponsiveHeight = (height) => height / iPhone6Height * WINDOW_HEIGHT;

export default class PaScrollableTabBar extends Component {
    static defaultProps = {
        scrollOffset: 52,
        backgroundColor: null,
        style: {},
        tabStyle: {},
        tabsContainerStyle: {},
        underlineStyle: {},
        showMoreChannels: () => {},
        scrollValue: new Animated.Value(0) 
    }

    constructor(props) {
        super(props);
        const { activeTab, tabs } = props;
        const leftTabUnderline = (activeTab === 0) ? 
            0 : Math.floor(tabs.slice(0, activeTab).join('').length * getResponsiveHeight(15)) + activeTab * 24;
        const offsetLength = (tabs[activeTab] && (activeTab !== 0)) ?
                                                 tabs[activeTab].length * 15 + 24 : 0;

        this._tabsMeasurements = [];
        this.underlayColor = '#ffffff';
        this.WINDOW_WIDTH = props.hasMoreBtn ? Dimensions.get('window').width - 45 : Dimensions.get('window').width;
        this.state = {
            _leftTabUnderline: new Animated.Value(leftTabUnderline),
            _widthTabUnderline: new Animated.Value(offsetLength),
            _containerWidth: props.tabs.length > 5 ? null : this.WINDOW_WIDTH,
            translateValue: new Animated.Value(0)
        };
    }

    componentDidMount() {
        const { tabs, activeTab } = this.props;
        const widthTabUnderline = activeTab === 0 ? 54 : tabs[activeTab].length * 15 + 24;
        this.props.scrollValue.addListener(this.updateView);
        this.state._widthTabUnderline.setValue(widthTabUnderline);
    }

    updateView = (offset) => {
        const position = Math.floor(offset.value);
        const pageOffset = offset.value % 1;
        const tabCount = this.props.tabs.length;
        const lastTabPosition = tabCount - 1;

        if (tabCount === 0 || offset.value < 0 || offset.value > lastTabPosition) {
            return;
        }

        if (this.necessarilyMeasurementsCompleted(position, position === lastTabPosition)) {
            this.updateTabPanel(position, pageOffset);
            this.updateTabUnderline(position, pageOffset, tabCount);
        }
    }

    necessarilyMeasurementsCompleted = (position, isLastTab) => {
        return this._tabsMeasurements[position] &&
        (isLastTab || this._tabsMeasurements[position + 1]) &&
        this._tabContainerMeasurements &&
        this._containerMeasurements;
    }

    updateTabPanel = (position, pageOffset) => {
        if (!this._scrollView) {
            return;
        }
        const containerWidth = this._containerMeasurements.width;
        const tabWidth = this._tabsMeasurements[position].width;
        const nextTabMeasurements = this._tabsMeasurements[position + 1];
        const nextTabWidth = nextTabMeasurements && nextTabMeasurements.width || 0;
        const tabOffset = this._tabsMeasurements[position].left;
        const absolutePageOffset = pageOffset * tabWidth;
        let newScrollX = tabOffset + absolutePageOffset;

        // center tab and smooth tab change (for when tabWidth changes a lot between two tabs)
        newScrollX -= (containerWidth - (1 - pageOffset) * tabWidth - pageOffset * nextTabWidth) / 2;
        newScrollX = newScrollX >= 0 ? newScrollX : 0;

        if (Platform.OS === 'android') {
            this._scrollView.scrollTo({ x: newScrollX, y: 0, animated: false, });
        } else {
            const rightBoundScroll = this._tabContainerMeasurements.width - (this._containerMeasurements.width) + 44;
            newScrollX = newScrollX > rightBoundScroll ? rightBoundScroll : newScrollX;
            this._scrollView.scrollTo({ x: newScrollX, y: 0, animated: false, });
        }

    }

    updateTabUnderline = (position, pageOffset, tabCount) => {
        const lineLeft = this._tabsMeasurements[position].left;
        const lineRight = this._tabsMeasurements[position].right;

        if (position < tabCount - 1) {
            const nextTabLeft = this._tabsMeasurements[position + 1].left;
            const nextTabRight = this._tabsMeasurements[position + 1].right;

            const newLineLeft = (pageOffset * nextTabLeft + (1 - pageOffset) * lineLeft);
            const newLineRight = (pageOffset * nextTabRight + (1 - pageOffset) * lineRight);

            this.state._leftTabUnderline.setValue(newLineLeft);
            this.state._widthTabUnderline.setValue(newLineRight - newLineLeft);
        } else {
            this.state._leftTabUnderline.setValue(lineLeft);
            this.state._widthTabUnderline.setValue(lineRight - lineLeft);
        }
    }

    renderTab = (name, page, isTabActive, onPressHandler, onLayoutHandler) => {
        const props = { name, page, isTabActive, onPressHandler, onLayoutHandler };
        return <Tab {...props} key={`${name}_${page}`} />;
    }

    measureTab = (page, event) => {
        const { x, width, height, } = event.nativeEvent.layout;
        this._tabsMeasurements[page] = { left: x, right: x + width, width, height, };
        this.updateView({ value: this.props.scrollValue._value, });
    }

    onTabContainerLayout = (e) => {
        this._tabContainerMeasurements = e.nativeEvent.layout;
        let width = this._tabContainerMeasurements.width;
        if (width < this.WINDOW_WIDTH) {
            width = this.WINDOW_WIDTH;
        }
        this.setState({ _containerWidth: width });
        this.updateView({ value: this.props.scrollValue._value, });
    }

    onContainerLayout = (e) => {
        this._containerMeasurements = e.nativeEvent.layout;
        this.updateView({ value: this.props.scrollValue._value, });
    }

    componentWillReceiveProps(nextProps) {
        // If the tabs change, force the width of the tabs container to be recalculated
        if (!isEqual(this.props.tabs, nextProps.tabs) && this.state._containerWidth) {
            const containerWidth = nextProps.tabs.length <= 5 ? this.WINDOW_WIDTH : null;
            this.setState({ _containerWidth: containerWidth });
        }
    }

    shouldComponentUpdate(nextProps, nextState) {
        const a = this.state._containerWidth;
        const b = nextState._containerWidth;

        /* 处理ios上的抖动问题 */
        if (a !== b && b > a) {
            this.staticWidth = b;
            return true;
        } else if (a !== b && a === this.staticWidth) {
            return false;
        }

        return !isEqual(this.props.tabs, nextProps.tabs) 
        || this.props.expand !== nextProps.expand
        || this.props.activeTab !== nextProps.activeTab;
    }

    render() {
        const tabUnderlineStyle = {
            position: 'absolute',
            height: 2,
            backgroundColor: '#ff6f00',
            bottom: 0,
        };

        const key = I18nManager.isRTL ? 'right' : 'left';
        const dynamicTabUnderline = {
            [`${key}`]: this.state._leftTabUnderline,
            width: this.state._widthTabUnderline
        };
        const { hasMoreBtn } = this.props;

        return (
            <View
                style={styles.container}
                onLayout={this.onContainerLayout}
                >
                <ScrollView
                    automaticallyAdjustContentInsets={false}
                    ref={(scrollView) => { this._scrollView = scrollView; }}
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    showsVerticalScrollIndicator={false}
                    directionalLockEnabled={true}
                    onScroll={this.props.onScroll}
                    bounces={false}
                    scrollsToTop={false}
                    style={styles.tabsContainer}
                    snapToAlignment="center"
                    centerContent={true}
                    bouncesZoom={false}
                    contentContainerStyle={{ justifyContent: 'center', height: 44 }}
                >
                    <View
                        style={[ styles.tabs, { width: this.state._containerWidth }, this.props.tabsContainerStyle ]}
                        onLayout={this.onTabContainerLayout}
                        >
                        {this.props.tabs.map((name, page) => {
                            const isTabActive = this.props.activeTab === page;
                            const renderTab = this.props.renderTab || this.renderTab;
                            return renderTab(name, page, isTabActive, this.props.goToPage, this.measureTab.bind(this, page));
                        })}
                        <Animated.View style={[ tabUnderlineStyle, dynamicTabUnderline, this.props.underlineStyle, ]} />
                    </View>
                </ScrollView>
                { hasMoreBtn && <Image style={{ width: 3, height: 44 }} source={{ uri: shadow }} /> }
                { hasMoreBtn &&
                    <TouchableHighlight 
                        style={styles.more} 
                        underlayColor={this.underlayColor}
                        onPress={this.props.showMoreChannels} >
                        <View style={[ styles.arrow, this.props.expand ? styles.arrowUp : styles.arrowDown ]} />
                    </TouchableHighlight>
                }
            </View>
        );
    }
}

PaScrollableTabBar.propTypes = {
    goToPage: PropTypes.func,
    activeTab: PropTypes.number,
    tabs: PropTypes.array,
    backgroundColor: PropTypes.string,
    scrollOffset: PropTypes.number,
    style: ViewPropTypes.style,
    tabStyle: ViewPropTypes.style,
    tabsContainerStyle: ViewPropTypes.style,
    textStyle: Text.propTypes.style,
    renderTab: PropTypes.func,
    underlineStyle: ViewPropTypes.style,
    onScroll: PropTypes.func,
    scrollValue: PropTypes.any,
    data: PropTypes.array,
    showMoreChannels: PropTypes.func
};