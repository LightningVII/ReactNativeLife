import React, { Component } from 'react';
import {
  TouchableHighlight,
  Text
} from 'react-native';
import styles from './styles';
import PropTypes from 'prop-types';

export default class Tab extends Component {  
    shouldComponentUpdate(nextProps) {
		return nextProps.isTabActive !== this.props.isTabActive;
	}

    render() {
        const { name, page, isTabActive, onPressHandler, onLayoutHandler } = this.props;
        
        return (
            <TouchableHighlight
                onPress={() => onPressHandler(page)}
                onLayout={onLayoutHandler}
                style={styles.tab}
                underlayColor="#ffffff"
            >
                <Text style={isTabActive ? styles.tabActiveText : styles.tabText}>{name}</Text>
            </TouchableHighlight>
        );
    }  
}

Tab.propTypes = {
    name: PropTypes.string,
    page: PropTypes.number,
    isTabActive: PropTypes.bool,
    onPressHandler: PropTypes.func,
    onLayoutHandler: PropTypes.func
};