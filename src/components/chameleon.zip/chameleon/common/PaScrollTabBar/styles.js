import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        height: 45,
        borderWidth: 1,
        borderTopWidth: 0,
        borderLeftWidth: 0,
        borderRightWidth: 0,
        borderColor: 'rgba(0, 0, 0, 0.12)',
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    tabsContainer: {
        flex: 1,
        height: 44
    },
    more: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center'
    },
    arrow: {
        borderRightWidth: 1,
        borderBottomWidth: 1,
        borderColor: '#212121',
        width: 10,
        height: 10,
    },
    arrowUp: {
        transform: [{
            rotateZ: '-135deg'
        }],
        marginTop: 8
    },
    arrowDown: {
        transform: [{
            rotateZ: '45deg'
        }]
    },
    tabs: {
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'space-around',
        alignItems: 'center',
        height: 44,
        overflow: 'hidden'
    },
    tab: {
        height: 44,
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 12,
        paddingRight: 12,
    },
    tabText: {
        color: '#212121',
        fontSize: 15
    },
    tabActiveText: {
        color: '#ff6f00',
        fontSize: 15
    },
    tabPanel: {
        backgroundColor: '#fff',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0
    }
});
export default styles;