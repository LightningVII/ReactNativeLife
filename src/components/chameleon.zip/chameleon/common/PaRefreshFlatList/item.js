import React, { Component } from 'react';
import PropTypes from 'prop-types';
import isEqual from 'lodash/isEqual';

export default class Item extends Component {
    static propTypes = {
        item: PropTypes.any,
        renderItem: PropTypes.func,
        extraData: PropTypes.any
    };

    shouldComponentUpdate(nextProps) {
        return !isEqual(this.props.item, nextProps.item) || !isEqual(this.props.extraData, nextProps.extraData);
    }

    render() {
        const { renderItem, item } = this.props;
        return item ? renderItem(item) : renderItem();
    }
}