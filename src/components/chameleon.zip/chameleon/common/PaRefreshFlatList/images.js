const ImagesPath = {
    kong: require('./kong.png'),
    lastTip: require('./lastTip.png'),
    loading: require('./loading.gif'),
    refresh: require('./refresh.gif'),
    refreshbg: require('./refreshbg.png')
}
module.exports = ImagesPath;
