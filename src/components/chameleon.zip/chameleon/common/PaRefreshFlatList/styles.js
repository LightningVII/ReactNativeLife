import {
    StyleSheet,
    Dimensions
} from 'react-native';
const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
    container: {
        flex: 1,
        // backgroundColor: '#ededed',
        position: 'relative',
        width
    },
    loadContainer: {
        height: 150,
        backgroundColor: '#ededed',
        justifyContent: 'flex-end',
        alignItems: 'center',
        position: 'relative',
        // width
    },
    loadBg: {
        width: 210,
        height: 105
    },
    loading: {
        position: 'absolute',
        bottom: 10,
        // left: (width - 56) / 2,
        width: 56,
        height: 56
    },
    moreLoadContainer: {
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    },
    moreloading: {
        width: 20,
        height: 20,
        marginRight: 5
    },
    lastTipContainer: {
        height: 80,
        justifyContent: 'center',
        alignItems: 'center'
    },
    lastTipImg: {
        width: 50,
        height: 30,
        marginBottom: 5
    },
    lastTipText: {
        color: '#999',
        fontSize: 12
    },
    emptyContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    emptyImg: {
        width: 100,
        height: 100
    },
    emptyText: {
        marginTop: 15,
        color: '#bbb',
        fontSize: 14
    },
    sepatatorContainer: {
        alignItems: 'flex-end',
        backgroundColor: '#fff'
    },
    sepatator: {
        width: width - 15,
        height: StyleSheet.hairlineWidth,
        backgroundColor: 'rgba(221, 221, 221, 0.6)',
    }
});
export default styles;
