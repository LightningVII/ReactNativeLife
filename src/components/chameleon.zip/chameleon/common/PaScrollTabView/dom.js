export const dpr = window.document && window.document.documentElement.dataset.dpr || 1;

// 获取requestAnimationFrame
export const getRAF = (func) => {
  const w = window;
  const prefixs = [ 'r', 'webkitR', 'mozR', 'msR', 'oR' ];
  // for(let i = 0; i < prefixs.length; i++){
  for (let prefix of prefixs) {
    prefix = `${prefix}equestAnimationFrame`;
    if (prefix in w) return w[prefix](func);
  }
  return setTimeout(func, 1e3 / 60);
};

// 获取CSS前缀
export const getStylePrefix = (style) => {
    const prefixs = [ 'webkit', 'Moz', 'ms', 'O' ];
    const dom = document.createElement('div').style;
    if (style in dom) return '';
    const newStyle = style.replace('-', ' ').replace(/(^|\s+)\w/g, s => s.toUpperCase()).replace(' ', '');
    // for (let i = 0; i < prefixs.length; i++) {
    for (const prefix of prefixs) {
        if ((prefix + newStyle) in dom) {
            return prefix;
        }
    }
    return null;
};

// 判断是否支持 transforms3d
export const isSupportTransform3D = () =>
  window.Modernizr && window.Modernizr.csstransforms3d === true || (() => {
                  const e = document.createElement('div').style;
                  return 'webkitPerspective' in e || 'MozPerspective' in e || 'OPerspective' in e || 'MsPerspective' in e || 'perspective' in e;
              })();

// 获取距离Body顶部的高度
export const getOffsetTop = (element) => {
  if (!element) return 0;
  let offsetTop = 0;
  let el = element;
  while (el.offsetParent) {
    offsetTop += el.offsetTop;
    el = el.offsetParent;
  }
  return offsetTop;
};

const linear = (time, start, diff, duration) => diff * time / duration + start;
const easeInOut = (time, start, diff, duration) => {
  let t = time;
  const b = start;
  const c = diff;
  const d = duration;
	if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
	return c / 2 * ((t -= 2) * t * t + 2) + b;
};
const tween = (curver, time, start, diff, duration) => {
  switch (curver) {
    case 'linear':
      return linear(time, start, diff, duration);
    case 'easeInOut':
      return easeInOut(time, start, diff, duration);
    default:
      return easeInOut(time, start, diff, duration);
  }
};

export const animate = (begin, end, duration, onProgress, onEnd, curver = 'easeInOut') => {
  const s = (new Date()).getTime();
  // const isObject = typeof begin === 'object' && !isArray(begin);
  const isNumber = typeof begin === 'number';
  const b = begin;
  let c;
  let keys;
  if (isNumber) {
    c = end - b;
  } else {
    keys = Object.keys(end);
    c = {};
    for (const key of keys) {
      c[key] = end[key] - b[key];
    }
  }
  const d = duration || 500;
  const calc = (t) => {
    if (typeof curver === 'function') return curver(t, b, c, d);
    if (isNumber) return tween(curver, t, b, c, d);
    const r = {};
    for (const key of keys) {
      r[key] = tween(curver, t, b[key], c[key], d);
    }
    return r;
  };
  (function execute() {
      let t = (new Date()).getTime() - s;
      if (t > d) {
          t = d;
          onProgress && onProgress(calc(t));
					onEnd && onEnd();
          return;
      }
      onProgress && onProgress(calc(t));
      // setTimeout(execute, 50);
      getRAF(execute);
  })();
};