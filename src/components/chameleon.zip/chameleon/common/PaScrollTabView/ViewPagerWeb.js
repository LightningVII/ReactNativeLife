import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import { findDOMNode } from 'react-dom';
import { dpr, getRAF, animate, getStylePrefix, isSupportTransform3D, getOffsetTop } from './dom';

export default class ViewPager extends Component {
  static defaultProps = {
    offset: 0,
    boundback: true,
    className: '',
  }
  constructor(props) {
    super(props);
    this.offset = props.offset * dpr;
    this.baseHeight = props.baseHeight * dpr;
    // this.height = (props.baseHeight * dpr || window.innerHeight) - this.offset;
    this.init = false;
    this.moveReady = true;
    this.moveThreshold = props.threshold || 20;
    this.duration = 350;
    this.resistanceRatio = props.resistanceRatio || 0.8;
    this.distance = document.body.clientWidth || document.documentElement.clientWidth;
    // 记住当前位置
    this.position = {};
    // CSS 兼容性
    let prefix = getStylePrefix('transform');
    prefix !== '' && (prefix = `-${prefix}-`);
    this.transform = `${prefix}transform`;
    prefix = getStylePrefix('transitionProperty');
    prefix !== '' && (prefix = `-${prefix}-`);
    this.transformStyle = isSupportTransform3D() ? 'translate3d' : 'translate';
    this.transitionProperty = `${prefix}transition-property`;
    this.transitionTimingFunction = `${prefix}transition-timing-function`;
    this.transitionDuration = `${prefix}transition-duration`;
    // 绑定监听Touch监听
    this.handleTouchStart = this.handleTouchStart.bind(this);
    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.handleTouchEnd = this.handleTouchEnd.bind(this);
    this.temp = '';
  }
  state = {
    currentIndex: null,
  }
  componentWillMount() {
    const { index, position, children } = this.props;
    this.position = position || {};
    if (typeof index === 'number' && index !== this.currentIndex) {
      const initIndex = index < 0 ? 0 : index;
      this.smoothMoveToIndex(initIndex, 0);
    }
    if (children) {
      this.initPagerView(children.length ? children.length : 1);
    }
    this.addStyleToHead();
  }

  addStyleToHead = () => {
    if (window.document) {
      const style = '<style id="react-native-stylesheet-scrolltopbar">\n' +
      '::-webkit-scrollbar { display:none; }\n' +
      '.xh-view-pager{overflow: hidden;}\n' +
      '.xh-view-pager .xh-pager-container{display: -webkit-box;display: -webkit-flex;display: flex;position: relative;will-change: transform;}\n' +
      '.xh-view-pager .xh-pager{min-width: 100%;max-width: 100%;display: block;overflow: hidden;}\n' +
      '.xh-scroll-box .xh-pager{overflow-y: scroll;-webkit-overflow-scrolling: touch;}\n' +
      '</style>';
      window.document.head.insertAdjacentHTML('afterbegin', style);
    }
  }

  componentDidMount() {
    // this.currNode = findDOMNode(this.currNodeRef);
    // this.pagerWrap = findDOMNode(this.pagerWrapRef);
    // this.initPosition();
  }

  componentWillReceiveProps(nextProps) {
    const { index, children } = nextProps;
    const count = React.Children.count(children);
    if (count && (count !== React.Children.count(this.props.children))) {
      this.initPagerView(count);
    }
    if (typeof index === 'number' && index !== this.props.index && this.props.shouldUpdated !== nextProps.shouldUpdated ) {
      this.currentIndex = index;
      const time = index === null ? 0 : 300;
      this.smoothMoveToIndex(index, time, true);
    }
  }
  shouldComponentUpdate(nextProps) {
    return true;
  }
  componentDidUpdate() {
    // this.initPosition();
  }
  componentWillUnmount() {
    this.getCurrPositions();
    this.timer && clearTimeout(this.timer);
    const { onRemember } = this.props;
    onRemember && onRemember(this.position);
    // this.detachScroll();
  }
  initPagerView(maxIndex) {
    this.maxIndex = maxIndex - 1;
    // this.setState({ style: this.setStyle() });
    // this.setStyle();
  }
  // 初始化位置
  initPosition() {
    const { position } = this.props;
    if (!this.init && position) {
      const childNodes = this.pagerWrap.childNodes;
      if (childNodes && childNodes.length) {
        this.init = true;
        Object.keys(position).map((scrollTop, index) => {
          if (childNodes[index]) {
            childNodes[index].scrollTop = scrollTop || 0;
          }
        });
      }
    }
  }
  handleTouchStart(e) {
    this.moveReady = false;
    this.scrolling = true;
    this.directionX = 0;
    this.moveOffset = 0;
    this.currentX = -this.currentIndex * this.distance;
    this.startPageX = e.changedTouches[0].pageX;
    this.startPageY = e.changedTouches[0].pageY;
    this.basePageX = e.changedTouches[0].pageX;
    this.startTime = Date.now();
    // , 'A'
    if ([ 'INPUT', 'TEXTAREA', 'BUTTON', 'SELECT' ].indexOf(e.target.tagName) !== -1) {
      e.preventDefault();
    }
  }
  handleTouchMove(e) {
    if (!this.scrolling) return;
    const pageX = e.changedTouches[0].pageX;
    const pageY = e.changedTouches[0].pageY;
    if (this.moveReady) {
      // const deltaX = pageX - this.basePageX;
      let deltaX = pageX - this.basePageX;
      this.directionX = deltaX === 0
        ? this.directionX
        : deltaX > 0 ? -1 : 1;
      if (this.props.boundback) {
        if (this.directionX === -1) {
          deltaX = -1 + Math.pow(deltaX, this.resistanceRatio);
        } else if (this.directionX === 1) {
          deltaX = 1 - Math.pow(-deltaX, this.resistanceRatio);
        }
      } else {
        if (this.directionX === -1) {
          deltaX = this.currentIndex === 0 ? 0 : -1 + Math.pow(deltaX, this.resistanceRatio);
        } else if (this.directionX === 1) {
          deltaX = this.currentIndex === this.maxIndex ? 0 : 1 - Math.pow(-deltaX, this.resistanceRatio);
        }
      }
      this.currentX += deltaX;
      // this.setState({ style: this.setStyle(this.currentX) });
      this.setStyle(this.currentX);
      this.basePageX = pageX;
    } else {
      const deltaX = Math.abs(pageX - this.startPageX);
      const deltaY = Math.abs(pageY - this.startPageY);
      const delta = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
      if (delta > 5) {
        const degValue = Math.acos(deltaY / delta);
        const deg = 180 / (Math.PI / degValue);
        if (deg > 65) {
          this.moveReady = true;
          e.preventDefault();
        } else {
          this.scrolling = false;
        }
      }
    }
  }
  handleTouchEnd(e) {
    let deltaX = Math.abs(e.changedTouches[0].pageX - this.startPageX);
    if (!this.scrolling || deltaX < 5) return;
    deltaX = -1 + Math.pow(deltaX, this.resistanceRatio);
    if (Date.now() - this.startTime > 10 && deltaX > this.moveThreshold) {
      let currentIndex = (-this.currentX) / this.distance;
      currentIndex = this.directionX > 0
        ? Math.ceil(currentIndex)
        : this.directionX < 0
          ? Math.floor(currentIndex)
          : Math.round(currentIndex);
      if (currentIndex < 0) {
        currentIndex = 0;
      } else if (currentIndex > this.maxIndex) {
        currentIndex = this.maxIndex;
      }
      // 获取当前位置
      this.smoothMoveToIndex(currentIndex);
    } else {
      // this.setState({ style: this.setStyle(-this.currentIndex * this.distance, 350) });
      this.setStyle(-this.currentIndex * this.distance, 350);
    }
    this.scrolling = false;
    this.moveReady = false;
  }
  smoothMoveToIndex(index, time, flag) {
    getRAF(() => {
      this.moveToIndex(index, time, flag);
    });
  }
  
  moveToIndex(index, time, flag) {
    let currentIndex = index;
    if (typeof currentIndex === 'undefined' || isNaN(currentIndex)) {
      currentIndex = this.currentIndex;
    }
    if (currentIndex < 0) {
      currentIndex = 0;
    } else if (currentIndex > this.maxIndex) {
      currentIndex = this.maxIndex;
    } else {
      currentIndex = parseInt(currentIndex);
    }
    this.currentX = -currentIndex * this.distance;
    const duration = (typeof time !== 'number' || time < 0) ? this.duration : time;
    // this.getCurrPositions(this.currentIndex);
    if (!flag) {
      this.getCurrPositions(this.currentIndex);
    }

    if (currentIndex !== this.currentIndex || flag) {
      this.setStyle(-currentIndex * this.distance, duration);
      this.currentIndex = currentIndex;
      const { onPageChange } = this.props;
      onPageChange && onPageChange(currentIndex);

      this.timer = setTimeout(() => {
        const { onPageChanged } = this.props;
        onPageChanged && onPageChanged(currentIndex);
        this.setScrollTop(currentIndex);
      }, duration);
    } else {
      this.setStyle(-currentIndex * this.distance, duration);
    }
  }
  // 获取当前页面的位置，用于记录用
  getCurrPositions(currIndex) {
    if (typeof this.currentIndex !== 'number' || this.currentIndex < 0) return;
    let index = currIndex;
    // if (typeof index === 'undefined') {
    if (typeof index !== 'number') {
      index = this.currentIndex;
    }
    if (this.pagerWrap.childNodes && this.pagerWrap.childNodes.length) {
      const scrollTop = this.pagerWrap.childNodes[index].scrollTop;
      this.position[index] = scrollTop;
    }
  }
  // 针对Window滚动记住位置
  scrollToCurrTop(currentIndex) {
    const offsetTop = getOffsetTop(this.currNode);
    if (offsetTop <= window.pageYOffset + this.offset) {
      window.scrollTo(0, (this.position[currentIndex] || (offsetTop - this.offset)));
    }
  }
  setStyle(offset, duration) {
    this.props.handleWebPageScroll && this.props.handleWebPageScroll(offset);
    const transformStyle = this.transformStyle.indexOf('3d') > -1 ? `${this.transformStyle}(${offset || 0}px, 0px, 0px)` : `${this.transformStyle}(${offset || 0}px, 0px)`;
    // this.pagerWrap.style[this.transitionProperty] = this.transProperty;
    // this.pagerWrap.style[this.transitionTimingFunction] = 'cubic-bezier(0,0,0.25,1)';
    // this.pagerWrap.style[this.transitionDuration] = `${duration || 0}ms`;
    // this.pagerWrap.style[this.transform] = transformStyle;
    let cssText = `${this.transitionProperty}:${this.transform};${this.transitionTimingFunction}:cubic-bezier(0,0,0.25,1);`;
    cssText += `${this.transitionDuration}:${duration || 0}ms;${this.transform}:${transformStyle};`;
    this.pagerWrap.style.cssText = cssText;
  }
  // 只设置当前对象及相邻对象
  setScrollTop(index) {
    const indexs = [ index - 1, index, index + 1 ];
    for (const index of indexs) {
      const scrollTop = this.position[index];
      if (typeof scrollTop === 'number') {
        const scrollNode = this.pagerWrap.childNodes[index];
        // scrollNode && (scrollNode.scrollTop = scrollTop);
        if (scrollNode) {
          const currScrollTop = scrollNode.scrollTop;
          animate(currScrollTop, scrollTop, 100, (value) => {
            scrollNode.scrollTop = value;
          }, () => {
            scrollNode.scrollTop = scrollTop;
          });
        }
      }
    }
  }
  renderChildren() {
    const { children } = this.props;
    const height = (this.baseHeight || window.innerHeight) - this.offset;
    return React.Children.map(children, (child, index) => (
        <div key={index} className="xh-pager" style={{ height }}>
          {child}
        </div>
      )
    );
  }
  render() {
    const { className, style, index } = this.props;
    let newClassName = `${className} xh-view-pager${scroll ? ' xh-scroll-box' : ''}`;
    
    return (
        <div ref={ref => this.currNodeRef = ref} 
          className={newClassName} style={style}>
          <div ref={ref => this.pagerWrapRef = ref} className="xh-pager-container" onTouchStart={this.handleTouchStart}
            onTouchMove={this.handleTouchMove} onTouchEnd={this.handleTouchEnd} onTouchCancel={this.handleTouchEnd}>
              {this.renderChildren()}
          </div>
        </div>
      );
  }
}
ViewPager.propTypes = {
  index: PropTypes.number,
  offset: PropTypes.number,
  height: PropTypes.number,
  baseHeight: PropTypes.number,
  boundback: PropTypes.bool,
  threshold: PropTypes.number,
  resistanceRatio: PropTypes.number,
  position: PropTypes.object,
  style: PropTypes.object,
  className: PropTypes.string,
  onPageChange: PropTypes.func,
  onPageChanged: PropTypes.func,
  onRemember: PropTypes.func,
  children: PropTypes.node
};
