import React, { Component } from 'react';
import {
  View,
  Platform
} from 'react-native';
import PropTypes from 'prop-types';

class SceneComponent extends Component { 
    static propTypes = {
        children: PropTypes.any,
        shouldUpdated: PropTypes.bool,
        initRefresh: PropTypes.bool,
        isFirst: PropTypes.bool
    }

    shouldComponentUpdate(nextProps) {
        if (this.props.forceUpdated || nextProps.forceUpdated || Platform.OS === 'web') {
            return true;
        }

        const nextTypeName = nextProps.children.type.name;
        const curTypeName = this.props.children.type.name;
        return nextProps.shouldUpdated && Boolean(nextTypeName) || curTypeName !== nextTypeName;
    }

    render() {
        const { children, initRefresh, isFirst, ...props } = this.props;
        if (children.type.name === 'View' && Platform.OS === 'web') {
            return children;
        } else {
            const child = children ? React.cloneElement(children, { initRefresh, isFirst, ...props }) : null;
            return child;
        }
    }
}

module.exports = SceneComponent;
