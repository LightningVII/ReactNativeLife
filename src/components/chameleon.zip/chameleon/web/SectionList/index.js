import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { findDOMNode } from 'react-dom';

export default class SectionList extends Component {
    constructor(props) {
        super(props);
        this.scrollTime = 0;
        this.threshold = 10;
    }

    static defaultProps = {
        ItemSeparatorComponent: () => {},
        renderSectionHeader: () => {},
        onEndReached: () => {},
        sections: [],
    };

    static propTypes = {
        ItemSeparatorComponent: PropTypes.func,
        renderSectionHeader: PropTypes.func,
        onEndReached: PropTypes.func,
        sections: PropTypes.array
    };

    componentDidMount() {
        this.currNode = findDOMNode(this.currNodeRef);
        this.scrollParent = this.getScrollParent(this.currNode.parentNode);
        this.scrollParent.addEventListener('scroll', this.handleScroll, false);
    }

    componentWillUnmount() {
        this.scrollParent.removeEventListener('scroll', this.handleScroll, false);
    }

    getScrollParent = (node) => {
        if (!node) {
          return document;
        }
        const excludeStaticParent = node.style.position === 'absolute';
        const overflowRegex = /(scroll|auto)/;
        let parent = node;
        while (parent) {
          if (!parent.parentNode || (parent.parentNode === (node.ownerDocument || document))) {
            return node.ownerDocument || document;
          }
          // const { position, overflow, overflowX, overflowY } = parent.style;
          const { position, overflow, overflowX, overflowY } = getComputedStyle(parent);
          if (position === 'static' && excludeStaticParent) {
            continue;
          }
          if (overflowRegex.test(overflow + overflowX + overflowY)) {
            return parent;
          }
          parent = parent.parentNode;
        }
        return node.ownerDocument || document;
    };

    handleScroll = (e) => {
        const { scrollTop, clientHeight, scrollHeight } = e.srcElement;
        if (scrollTop + clientHeight + this.threshold >= scrollHeight) {
            this._onEndReached();
        }
    }

    _onEndReached = () => {
        const { onEndReached } = this.props;
        const now = (new Date()).getTime();
        if (now - this.scrollTime > 150) {
            onEndReached && onEndReached();
        }
        this.scrollTime = now;
    }
    
    render() {
        const { sections, renderSectionHeader, ItemSeparatorComponent } = this.props;
        return (
            <div ref={ref => this.currNodeRef = ref}>
                {
                    sections.map((v, i) => {
                        return (
                            <div key={i}>
                                {renderSectionHeader({ section: v })}
                                {
                                    v.data.map((item, index) => <div key={`section-item-${index}`}>{v.renderItem({ item })}</div>)
                                }
                                {
                                    i !== sections.length - 1 &&
                                    ItemSeparatorComponent()
                                }
                            </div>
                        );
                    })
                }
            </div>
        );
    }
}