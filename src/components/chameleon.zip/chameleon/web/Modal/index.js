import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
import './styles.scss';

export default class Modal extends Component {
    constructor(props) {
        super(props);
        this.node = document.createElement('div');
        this.modalRoot = document.body;
    }

    static defaultProps = {
        animationType: 'slide',
        transparent: false,
        visible: false,
        onRequestClose: () => {},
    };

    static propTypes = {
        animationType: PropTypes.string,
        transparent: PropTypes.bool,
        visible: PropTypes.bool,
        onRequestClose: PropTypes.func,
        children: PropTypes.any,
    };

    componentDidMount() {
        this.modalRoot.appendChild(this.node);  
    }

    componentWillUnmount() {
        this.modalRoot.removeChild(this.node);
    }
    
    render() {
        const dom = (
            <div className="rn-modal">
                {this.props.children}
            </div>
        );
        const { visible } = this.props;
        return visible ? ReactDOM.createPortal(dom, this.node) : null;
    }
}