import React, { Component } from 'react';
import createHashHistory from 'history/createHashHistory';
import PropTypes from 'prop-types';
import UrlPattern from 'url-pattern';

class PaRouter extends Component {

    state = {
        route: this.props.routes[0]
    }

    static propTypes = {
        routes: PropTypes.array,
        basename: PropTypes.string,
        hashType: PropTypes.oneOf([ 'hashbang', 'noslash', 'slash' ])
    }

    componentWillMount() {

        const history = createHashHistory({
            basename: this.props.basename || ''
        })

        // 初次渲染
        const location = history.location;
        this.locationHandler(location);

        // 变更监听
        const unlisten = history.listen((location, action) => {
            this.locationHandler(location);
        })

    }

    locationHandler(location) {
        const hash = location.pathname;
        const nextRoute = this.getMatchedRoute(hash);

        if(nextRoute){

            // 添加params信息
            let pattern = new UrlPattern(nextRoute.path);
            let params = pattern.match(hash) || {};
            nextRoute.params = params;

            // 渲染页面组件
            this.setState({
                route: nextRoute
            })
        }
    }

    getMatchedRoute(hash) {

        // 匹配当前hash对应的路由
        let possibleRoutes = this.props.routes.filter((value, index, arr) => {
            let pattern = new UrlPattern(value.path);
            return pattern.match(hash);
        })

        // 返回当前路由
        console.log('匹配路由', possibleRoutes);
        if(possibleRoutes) {
            if(possibleRoutes.length > 1) {
                console.error('有多个可匹配的路由');
            } else if(possibleRoutes.length == 0) {
                console.error('无匹配路由');
            } else {
                return possibleRoutes[0];
            }
        } else {
            // todo 渲染404页面
            console.error('无匹配路由');
        } 

        return null;
    }

    render() {
        const route = this.state.route;

        return (
            <route.component {...route.params} />
        )
    }
}

export default PaRouter;