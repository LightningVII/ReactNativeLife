import Router from './PaRouter';
import UrlPattern from 'url-pattern';


let routes = [];

/**
 * 注册web端路由
 * @param {object} params 
 */
const registRoutes = (params) => {
  routes = params;
}

// 项目内跳转
const transitionTo = (options) => {
    const { container, params } = options;

    // 寻找对应的web端路由信息
    let currRoute = routes.find((value, index, arr) => {
        return value.name == container;
    });

    if (currRoute) {
        let pattern = new UrlPattern(currRoute.path);

        // 拼装目标地址
        let hash = pattern.stringify(params);

        window.location.hash = hash;

    } else {
        alert('找不到路由！');
    }
}

// 跳转到Native
const transitionToNative = (options) => {
    const { url, pageTag, params } = options;
    RNViewManager.openUrl(url, pageTag, params);
}

// 跳转到Webview
const transitionToWebview = (options) => {
    const { url, pageTag, params } = options;
    window.location = url;
}

// 关闭页面
const closeCurrentPage = (pageTag) => {
    window.history.back();
}

export default {
    transitionTo,
    transitionToNative,
    transitionToWebview,
    Router,
    closeCurrentPage,
    registRoutes
}
