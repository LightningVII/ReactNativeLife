/**
 * Pajk 通用 api请求库
 */
import 'whatwg-fetch';
// import fetch from './fetch';
import md5 from 'blueimp-md5';
import { Promise } from 'es6-promise';

const DEFAULT_SALT = 'jk.pingan.com';

// TODO getcookie 和 serialize 方法可以扔到公用方法里去
function getCookie(name) {
  const reg = new RegExp(`(^| )${name}=([^;]*)(;|$)`);
  const arr = window.document.cookie.match(reg);
  if ( arr ) {
    return decodeURIComponent(arr[2]);
  } else {
    return null;
  }
}

function serialize(obj, prefix) {
  const str = [];
  for (const p in obj) {
    if (obj.hasOwnProperty(p)) {
      const k = prefix ? `${prefix}[" + p + "]` : p;
      const v = obj[p];
      str.push(`${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
    }
  }
  return str.join('&');
}

function getHash(level) {
  const ut = getCookie('_wtk');
  if (level === 'None') {
    return DEFAULT_SALT;
  } else if (ut) {
    return ut;
  } else {
    return window.localStorage.getItem('CF_TOKEN');
  }
}

function encrypt(level, params) {
  params._st = Number(new Date);
  // params._sv = getCookie('projId');
  params._sm = 'md5';
  let s = '';
  const keys = [];
  for (const k in params) {
    if (params.hasOwnProperty( k )) {
      keys.push(k);
    }
  }

  keys.sort();
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    s = `${s}${key}=${params[key]}`;
  }
  s += getHash(level);

  params._sig = md5(s);
  return params;
}

function request(params) {
  const { _api, _st, ...others } = params; // 与react-native 共用安全级别
  const data = encrypt(_st, others);
  return fetch(_api, {
    method: 'post',
    headers: {
      'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
    },
    credentials: 'include',
    body: serialize(data)
  })
  .then(response => response.json())
  .then((data) => {
    if (data && data.stat && data.stat.code < 0) { // api网关错误
      const error = new Error(data.stat.code);
      return Promise.reject(error);
    } else if (data &&
      data.stat &&
      data.stat.stateList &&
      data.stat.stateList.length > 0 &&
      data.stat.stateList[0].code !== 0) { // 业务逻辑错误
      const error = new Error(data.stat.stateList[0].code);
      return Promise.reject(error);
    } else if (data.content && data.content[0]) { // 请求成功
      return data.content[0];
    }
    // 其他情况
    return data;
  });
}

export default { request };
