import Querystring from 'querystring';
const DEFAULT_SHARE_CONTENT = '看健康头条，上平安好医生';

function getVersionCode() {
  const versionMatch = (/pajkAppVersion\/(\d{5})/).exec(window.navigator.userAgent) || (/pajk_(\d+)/).exec(window.navigator.userAgent);
  return versionMatch ? Number(versionMatch[1]) : 0;
};

function addQuery(url, obj) {
  return url.indexOf('?') >= 0  ? `${url}&${Querystring.stringify(obj)}` : `${url}?${Querystring.stringify(obj)}`;
}

// 获取获取移到平台
function getMobileOS() {
  const userAgent = navigator.userAgent || navigator.vendor || window.opera;
  if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i) || userAgent.match(/iPod/i)) {
    return 'iOS';
  } else if (userAgent.match(/Android/i)) {
    return 'Android';
  } else { // 默认为iOS,方便桌面端调试
    return 'iOS';
  }
};

function newPreShareInfo(action, shareInfo, channels) {
  let { title, content, imageUrl, preLink, afterLink } = shareInfo;
	title = title || DEFAULT_SHARE_CONTENT;
	content = content || DEFAULT_SHARE_CONTENT;
	imgUrl = imageUrl;
	const contentType = 4;
	const itemShare = { title: title, content: content, imageUrl: imgUrl, contentType: contentType };
	const mainContent = {};

	let itemList = [];
	if (channels.indexOf('friends') > -1) {
    const pageUrl = addQuery(preLink, { channel: 'weixin', business: 'friends' }) + afterLink;
		itemList.push({ ...itemShare, shareType: 1, pageUrl: pageUrl,  });
	}
	if (channels.indexOf('timeline') > -1) {
    const pageUrl = addQuery(preLink, { channel: 'weixin', business: 'timeline' }) + afterLink;
		itemList.push({ ...itemShare, shareType: 2, pageUrl: pageUrl,  });
	}
	if (channels.indexOf('weibo') > -1) {
    const pageUrl = addQuery(preLink, { channel: 'weibo', }) + afterLink;
		itemList.push({ ...itemShare, shareType: 3, pageUrl: pageUrl,  });
	}


	itemList = JSON.stringify(itemList);
	const extInfo = {
	}
	const resultActionInfo = {
	}
	return `{"content":${JSON.stringify(mainContent)},"source":"eva-rn","action":${action},"itemList":${itemList},"ext": ${JSON.stringify(extInfo)}, "resultAction": ${JSON.stringify(resultActionInfo)}}`;
}
function preShareInfo(shareInfo) {
  let { title, content, imageUrl, preLink, afterLink } = shareInfo;
  let shareList = [];
  const pic = encodeURIComponent(imageUrl);

  title = title || DEFAULT_SHARE_CONTENT;
	content = content || DEFAULT_SHARE_CONTENT;

  const share = { appTit: title, appContent: content, appUrl: pic };
  const weixin = addQuery(preLink, { channel: 'weixin', business: 'friends' }) + afterLink;
  const timeline = addQuery(preLink, { channel: 'weixin', business: 'timeline' }) + afterLink;
  const weibo = addQuery(preLink, { channel: 'weibo'}) + afterLink;

  shareList.push({ ...share, appPage: weixin, shareType: 1 },{ ...share, appPage: timeline, shareType: 2 },{ ...share, appPage: weibo, shareType: 3 });
  return shareList;
}
function preShare(shareInfo, pageTag) {
    let info = encodeURIComponent(JSON.stringify({
			"shareList":preShareInfo(shareInfo)
		}));
    let appVersion = getVersionCode();
    if (appVersion >= 50400) {
      info = encodeURIComponent(newPreShareInfo(0, shareInfo, [ 'friends', 'timeline', 'weibo' ]));
      // window.location.href = `pajk://global_sns_share?content=${info}`;
    }
    window.location.href = `pajk://global_share_preparedata?content=${info}`;
}

function share(pageTag = undefined, shareInfo) {
  let appVersion = getVersionCode();
    if (appVersion >= 50400) {
      const info = encodeURIComponent(newPreShareInfo(1, shareInfo, [ 'friends', 'timeline', 'weibo' ]));
      window.location.href = `pajk://global_sns_share?content=${info}`;
    }
    window.location.href = `pajk://global_share_showshareview?`;
}

export default { preShare, share };
