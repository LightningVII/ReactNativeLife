if (!Array.prototype.slice.call(document.getElementsByTagName('script')).some(function (node) {
  return node.src.indexOf('beacon.js') !== -1;
})) {
  var baconUrl = '';
  if (location.host.indexOf("dev.pajkdc.com") != -1) {
    // 开发环境
    baconUrl = 'https://api.dev.pajkdc.com/js/beacon.js';
  } else if (location.host.indexOf("test.pajkdc.com") != -1 || location.host.indexOf("test.pajk.cn") != -1) {
    // 测试环境
    baconUrl = 'https://beacon.test.pajkdc.com/js/beacon.js';
  } else if (location.host.indexOf("pre.jk.cn") != -1) {
    // 预发环境
    baconUrl = 'https://beacon.pre.jk.cn/js/beacon.js';
  } else if (location.host.indexOf("jk.cn") != -1 || location.host.indexOf("pahys.com") != -1) {
    // 正式线上环境
    baconUrl = 'https://beacon.jk.cn/js/beacon.js';
  } else {
    //default
    baconUrl = 'https://beacon.jk.cn/js/beacon.js';
  }

  var script = document.createElement('script');
  //script.async = true;
  script.src = baconUrl;
  document.getElementsByTagName("head")[0].appendChild(script);
}

const getParameterByName = (name, url) => {
  let myUrl;
  if (!url) myUrl = window.location.search;
  const myName = name.replace(/[\[\]]/g, '\\$&');
  const regex = new RegExp(`[?&]${myName}(=([^&#]*)|&|#|$)`);
  const results = regex.exec(myUrl);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

const logHandler = () => {
  let userId = '';
  let project = '';

  function init(userId, project){
    this.userId = userId;
    this.project = project;
  }

  function setLog(options = {}){
    if (window.pajkLogger) {
      try {
        const params = Object.assign({
          607: this.project || '',
          4: getParameterByName('channel') || '',
          602: getParameterByName('business') || '',
          503: getParameterByName('activity') || '',
          22: getParameterByName('choice') || '',
          610: getParameterByName('source') || '',
          33: this.userId || ''
        }, options)
        window.pajkLogger.clickLog(params);
      } catch (e) {
        throw new Error(`打点出错: ${e.message})`);
      }
    }
  }

  function setPageEnterLog(pageName){
    setLog({
      32: pageName,
      29: 'onload'
    });
  }

  function setPageLeaveLog(pageName){
    setLog({
      32: pageName,
      29: 'leave'
    });
  }

  function setEventLog(event, options = {}){
    const params = Object.assign(options, { 29: event || '' });
    setLog(params);
  }

  function setClickLog(params) {
    // todo:
    console.log('%c 打点日志输出：', 'color:red', params);
  }

  return {
      init,
      setPageEnterLog,
      setPageLeaveLog,
      setEventLog,
      setClickLog
  };
}

export default logHandler();
