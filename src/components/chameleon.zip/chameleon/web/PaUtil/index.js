// 设置标题
const setTitle = (title, pageTag) => {
    document.title = title;
}

// nonsupport  
// todo:
const scheme = (scheme, pageTag = undefined) => new Promise(resolve => {
    window.location.href = scheme;
});

// 获取app版本信息
const getAppVersion = () => {
  const versionMatch = (/pajkAppVersion\/(\d{5})/).exec(window.navigator.userAgent) || (/pajk_(\d+)/).exec(window.navigator.userAgent);
  return new Promise((resolve, reject) => {
		resolve(versionMatch ? Number(versionMatch[1]) : 0);
  });
};

export default {
    setTitle,
    scheme,
    getAppVersion
}
