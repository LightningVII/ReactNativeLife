import React, { Component } from 'react';
import {
  Text,
  View,
  FlatList,
  Dimensions,
  Animated,
  PanResponder,
  Image
} from 'react-native';
import styles from '../../common/PaRefreshFlatList/styles';
import PropTypes from 'prop-types';
import Item from '../../common/PaRefreshFlatList/item';
import { findDOMNode } from 'react-dom';
import { dpr, getScrollParent, getStylePrefix, isSupportTransform3D } from './dom';
import ImagesPath from '../../common/PaRefreshFlatList/images';

const { height, width } = Dimensions.get('window');

// 0: 未刷新; 1: 到达刷新点; 2: 刷新中; 3: 刷新完成
export const RefreshState = {
  pullToRefresh: 0,
  releaseToRefresh: 1,
  refreshing: 2,
  refreshdown: 3,
};

export const RefreshText = {
  pullToRefresh: 'pull to refresh',
  releaseToRefresh: 'release to refresh ',
  refreshing: 'refreshing...',
  refreshdown: 'refresh complete!'
};

export const FooterText = {
  pushToRefresh: 'pull to refresh',
  loading: 'refreshing...'
};

export default class PaRefreshFlatList extends Component {  
    static defaultProps = {
        initRefresh: false,
        data: [],
        hasNext: false,
        offset: 0,
        noRefreshControl: false
    };

    static propTypes = {
        initRefresh: PropTypes.bool,
        data: PropTypes.array,
        hasNext: PropTypes.bool,
        renderItem: PropTypes.func,
        renderHead: PropTypes.func,
        ItemSeparatorComponent: PropTypes.func,
        ListFooterComponent: PropTypes.func,
        onLoad: PropTypes.func,
        onRefreshed: PropTypes.func,
        offset: PropTypes.number,
        noRefreshControl: PropTypes.bool,
        extraData: PropTypes.any,
        style: PropTypes.any,
        onScroll: PropTypes.func
    };

    constructor(props) {
        super(props);
        this.state = {
            rotation: new Animated.Value(0),
            refreshState: RefreshState.pullToRefresh,
            refreshText: RefreshText.pullToRefresh,
            percent: 0,
            footerMsg: 'load more',
        };
        this.headerHeight = 150;
        this.threshold = 5 * dpr;
        this.beforeRefreshState = RefreshState.pullToRefresh;
        this.loadmore = true;
        this.refreshing = false;  // 刷新状态
        this.loading  = false;
        this.scrollTime = 0;
        // CSS 兼容性
        let prefix = getStylePrefix('transform');
        if (prefix === '') {
        this.transform = 'transform';
        this.transProperty = 'transform';
        } else {
        this.transform = `${prefix}Transform`;
        this.transProperty = `-${prefix}-transform`;
        }
        prefix = getStylePrefix('transition');
        prefix = prefix === '' ? 't' : `${prefix}T`;
        this.transformStyle = isSupportTransform3D() ? 'translate3d' : 'translate';
        this.transitionProperty = `${prefix}ransitionProperty`;
        this.transitionTimingFunction = `${prefix}ransitionTimingFunction`;
        this.transitionDuration = `${prefix}ransitionDuration`;
        this.addStyleToHead();
    }

    componentDidMount() {
        this.currNode = findDOMNode(this.currNodeRef);
        this.scrollParent = getScrollParent(this.currNode.parentNode);
        const { initRefresh, noRefreshControl, forceUpdate } = this.props;
        this.attachTouch();
        if ((!noRefreshControl && initRefresh) || forceUpdate) {
            this._onRefresh();
        }
    }

    attachTouch() {
        const { noRefreshControl } = this.props;
        if (!noRefreshControl) {
            this.currNode.addEventListener('touchstart', this.handleTouchStart, false);
            this.currNode.addEventListener('touchmove', this.handleTouchMove, false);
            this.currNode.addEventListener('touchend', this.handleTouchEnd, false);
            this.currNode.addEventListener('touchcancel', this.handleTouchEnd, false);
        }
        this.scrollParent.addEventListener('scroll', this.handleScroll, false);
    }

    detachTouch() {
        const { noRefreshControl } = this.props;
        if (!noRefreshControl) {
            this.currNode.removeEventListener('touchstart', this.handleTouchStart, false);
            this.currNode.removeEventListener('touchmove', this.handleTouchMove, false);
            this.currNode.removeEventListener('touchend', this.handleTouchEnd, false);
            this.currNode.removeEventListener('touchcancel', this.handleTouchEnd, false);
        }
        this.scrollParent.removeEventListener('scroll', this.handleScroll, false);
    }

    _onRefresh() {
        try {
            this.refreshing = true;
            const { onLoad } = this.props;
            this.setRefreshState(true);
            return onLoad && onLoad('refresh').then(() => {
                this.setRefreshState(false);
            }, () => {
                this.setRefreshState(false);
            }).catch(() => {
                this.setRefreshState(false);
            });
        } catch (e) {
            throw new Error('刷新函数不支持Promise');
        }
    }

    componentWillUnmount() {
        this.setStyle(0);
        this.t && clearTimeout(this.t);
        this.tt && clearTimeout(this.tt);
        this.touchEndTimer && clearTimeout(this.touchEndTimer);
        this.detachTouch();
    }

    setRefreshState(refreshing) {
        if (refreshing) {
            this.beforeRefreshState = RefreshState.refreshing;
            this.updateRefreshViewState(RefreshState.refreshing);
        } else {
            if (this.beforeRefreshState === RefreshState.refreshing) {
                this.beforeRefreshState = RefreshState.pullToRefresh;
                this.updateRefreshViewState(RefreshState.refreshdown);
            } else {
                // this.updateRefreshViewState(RefreshState.pullToRefresh)
            }
        }
    }

    updateRefreshViewState(refreshState = RefreshState.pullToRefresh) {
        const { noRefreshControl } = this.props;
        switch (refreshState) {
            case RefreshState.pullToRefresh:
                this.setState({ 
                    refreshState: RefreshState.pullToRefresh, 
                    refreshText: RefreshText.pullToRefresh
                });
            break;
            case RefreshState.releaseToRefresh:
                this.setState({
                    refreshState: RefreshState.releaseToRefresh, 
                    refreshText: RefreshText.releaseToRefresh
                });
            break;
            case RefreshState.refreshing:
                this.setState({
                    refreshState: RefreshState.refreshing, 
                    refreshText: RefreshText.refreshing
                }, () => {
                    !noRefreshControl && this.setStyle(this.headerHeight * 0.5, 300);
                });
            break;
            case RefreshState.refreshdown:
                this.setState({
                    refreshState: RefreshState.refreshdown, 
                    refreshText: RefreshText.refreshdown, percent: 100 }, () => {
                    // This delay is shown in order to show the refresh time to complete the refresh
                    this.t = setTimeout(() => {
                        !noRefreshControl && this.setStyle(0, 500);
                        this.tt = setTimeout(() => {
                            this.updateRefreshViewState(RefreshState.pullToRefresh);
                        }, 300);
                        const { onRefreshed } = this.props;
                        onRefreshed && onRefreshed();
                        this.refreshing = false;
                    }, 500);
                });
                break;
            default:
                break;
        }
    }

    _onEndReached = () => {
        const { onLoad, hasNext } = this.props;
        // this.loadmore: 控制请求次数
        // hasNext: 是否有下一页
        // this.refreshing: 是否处于正在刷新中
        const now = (new Date()).getTime();
        if (this.loadmore && hasNext && !this.refreshing  && (now - this.scrollTime > 150)) {
            this.loadmore = false;
            onLoad && onLoad('more').then(() => {
                this.loadmore = true;
            });
        }
        this.scrollTime = now;
    }

    handleScroll = (e) => {
        const { onScroll } = this.props;
        onScroll && onScroll(e);
        
        const { scrollTop, clientHeight, scrollHeight } = e.srcElement;
        if (scrollTop + clientHeight + this.threshold >= scrollHeight) {
            this._onEndReached();
        }
    }

    handleTouchStart = (e) => {
        this.refreshing && e.stopPropagation();
        if (this.loading) return;
        this.loading = true;
        this.canScroll = false;
        this.direction = 0;
        this.startHeight = 0;
        this.moving = false;
        this.scrollEndY = 0;
        this.startX = e.touches[0].pageX;
        this.startY = e.touches[0].pageY;
    }

    handleTouchMove = (e) => {
        this.refreshing && e.stopPropagation();
        this.moving = true;
        // 暂时设定为距屏幕左侧距离，（应该为距离ScrollParent的左侧距离，一般情况下ScrollParent宽度为整个屏幕）
        if (this.currNode.getBoundingClientRect().left !== 0) return;
        const pageY = e.touches[0].pageY;
        
        // 避免上拉过程中调用refresh方法
        if (pageY > this.scrollParent.clientHeight - this.threshold) {
            this.touchEndTimer = setTimeout(() => {
                this.loading = false;
            }, 200);
            return;
        }

        let diffY = pageY - this.startY;
        if (diffY > 0) {
            diffY = -1 + Math.pow(diffY, 0.9);
            this.setStyle(diffY);
        } 
        this.scrollEndY = diffY;
    }

    handleTouchEnd = (e) => {
        e.preventDefault(); 
        this.touchEndTimer && clearTimeout(this.touchEndTimer);

        if (this.scrollEndY > this.headerHeight * 0.5 && this.loading && this.scrollParent.scrollTop < this.threshold) {
            this._onRefresh();
        } else {
            // if (this.moving && Math.abs(this.scrollEndY) > 5) {
            //     e.stopPropagation();
            // }
            this.setStyle(0, 300);
        }
        this.loading = false; 
    }

    setStyle(offset = 0, duration = 0) {
        const transformStyle = this.transformStyle.indexOf('3d') > -1 ? `${this.transformStyle}(0px, ${offset || 0}px, 0px)` : `${this.transformStyle}(0px, ${offset || 0}px)`;
        this.currNode.style[this.transitionProperty] = this.transProperty;
        this.currNode.style[this.transitionTimingFunction] = 'cubic-bezier(0,0,0.25,1)';
        this.currNode.style[this.transitionDuration] = `${duration}ms`;
        this.currNode.style[this.transform] = transformStyle;
    }

    addStyleToHead = () => {
        // if (window.document) {
        //     const dom = window.document.getElementById('react-native-stylesheet-flatlist');
        //     if (!dom) {
        //         const style = '<style id="react-native-stylesheet-flatlist">\n' +
        //         '::-webkit-scrollbar { display:none; }\n' +
        //         '.rn-overflow-auto {overflow:auto;}\n' +
        //         '.rn-flatlist {overflow: auto;position: relative;height: 100%;}\n' +
        //         '</style>';
        //         window.document.head.insertAdjacentHTML('afterbegin', style);
        //     }
        // }
    }

    _renderItem = (item, index) => {
        return <Item item={{item}} key={`fl-${index}`} {...this.props} />;
    }

    _ListHeaderComponent = () => {
        // const { refreshState, refreshText, percent } = this.state;
        const { noRefreshControl, extraData, renderHead } = this.props;
        const head = renderHead ? <Item item={extraData} renderItem={renderHead} /> : null;
        if (noRefreshControl) {
            return head;
        }
        return (
            <View>
                <Animated.View style={[ styles.loadContainer, {width: Dimensions.get('window').width, marginTop: -this.headerHeight }]}>
                    <Animated.Image 
                    source={ImagesPath.refreshbg} 
                    style={styles.loadBg} 
                    resizeMode="contain" />
                    <Animated.Image 
                        source={ImagesPath.refresh} 
                        style={[styles.loading, {left: (Dimensions.get('window').width - 56) / 2,}]} 
                        resizeMode="contain" />
                </Animated.View>
                { head }
            </View>    
        );
    }

    _ListFooterComponent = () => {
        const { hasNext, data, ListFooterComponent } = this.props;
        if (data.length === 0) {
            return null;
        }
        if (hasNext) {
            return (
                <View style={styles.moreLoadContainer}>
                    <Image 
                        source={ImagesPath.loading} 
                        style={styles.moreloading} 
                        resizeMode="contain" />
                    <Text>正在加载中...</Text>  
                </View> 
            );
        } else {
            if (ListFooterComponent !== undefined ) {
                return ListFooterComponent;
            }
            return (
                <View style={styles.lastTipContainer}>
                    <Image 
                        source={ImagesPath.lastTip} 
                        style={styles.lastTipImg} 
                        resizeMode="contain" />
                    <Text style={styles.lastTipText}>已经到底啦</Text>
                </View>  
            );
        }
    }

    _ListEmptyComponent = () => {
        const offset = this.props.offset || 0;
        if (this.state.refreshState !== RefreshState.pullToRefresh && this.refreshing) {
            return <View style={[ styles.emptyContainer, { height: height - offset, width }]} />;
        }
        return (
            <View style={[ styles.emptyContainer, { height: height - offset, width }]}>
                <Image 
                    source={ImagesPath.kong} 
                    style={styles.emptyImg} 
                    resizeMode="contain" />
                <Text style={styles.emptyText}>这里空空如野，什么也没搜到~</Text>
            </View>
        );
    }

    _ItemSeparatorComponent = (data) => {
        const { ItemSeparatorComponent } = this.props;
        return ItemSeparatorComponent ? 
            <Item item={data.leadingItem} renderItem={ItemSeparatorComponent} /> : 
            null;
    }

    render() {
        const { data, extraData, noRefreshControl, style, updateDimension } = this.props;
        let dom;
        updateDimension && updateDimension();
        if (data.length === 0) {
            dom = this._ListEmptyComponent();
        } else {
            dom = (
                <View>
                    {
                        data.map((item, index) => {
                            return this._renderItem(item, index);
                        })
                    }
                    {this._ListFooterComponent()}
                </View>
            )
        }
        return (
            <View className="rn-flatlist" onMoveShouldSetResponder={() => true}>
                <View style={[ styles.container, {width: Dimensions.get('window').width}, style ]} ref={ref => this.currNodeRef = ref}>
                    {this._ListHeaderComponent()}
                    {dom}
                </View>
            </View>
        );
    }
}