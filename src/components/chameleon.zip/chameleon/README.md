# 依赖关系

库 | 依赖
-- | --
`react-native@0.42.3` | `react~15.4.1`
`react-native-web@0.1.0` | `react, react-dom: 16.x.x`
`react-native-scrollable-tab-view@0.7.4` | `react-native >=0.20.0`

# 备注
```
~1.2.3 will match all 1.2.x versions but will miss 1.3.0.

^1.2.3 will match any 1.x.x release including 1.3.0, but will hold off on 2.0.0.
```
