import { StyleSheet, Dimensions } from 'react-native'

const {width} = Dimensions.get('window')

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F8',
    width: width
  },
  loadingContainer: {
    alignSelf: 'center',
    top: '49%',
    position: 'absolute'
  }
})

export default styles
