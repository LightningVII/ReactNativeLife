import React, { Component } from 'react'
import { ScrollView, Platform, Dimensions, View } from 'react-native'

import ReportCard from '../ReportCard'
import FamilyDoctor from '../FamilyDoctor'
import Header from '../Header'
import styles from './styles'

export default class Home extends Component {
  isIphoneX () {
    const {height, width} = Dimensions.get('window')
    return (
        Platform.OS === 'ios' &&
        !Platform.isPad &&
        !Platform.isTVOS &&
        (height === 812 || width === 812)
    )
  }

  render () {
    const {headerProps, familyDoctorProps, reports, onScroll} = this.props
    const height = Platform.OS === 'ios' && (this.isIphoneX() ? 44 : 20)
    return (
      <ScrollView style={styles.container} scrollEventThrottle={2} onScroll={onScroll} bounces={false} >
        {height && <View style={{height}} />}
        <Header {...headerProps} />
        <FamilyDoctor {...familyDoctorProps} />
        <ReportCard reports={reports} />
      </ScrollView>
    )
  }
}

Home.propTypes = {}
