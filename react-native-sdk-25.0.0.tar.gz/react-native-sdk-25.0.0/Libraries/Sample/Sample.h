#import <React/RCTBridgeModule.h>

@interface Sample : NSObject <RCTBridgeModule>

@end
